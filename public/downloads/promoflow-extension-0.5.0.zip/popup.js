"use strict";
(() => {
  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host) || isShopeeHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || [
        "meli.la",
        "www.meli.la",
        "amzn.to",
        "a.co",
        "shope.ee",
        "shp.ee"
      ].some((domain) => url.hostname === domain || url.hostname.endsWith("." + domain)));
    } catch {
      return false;
    }
  }

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre, na Amazon Brasil ou na Shopee."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector.js"]
    });
    const data = injection?.result;
    if (!isCapturedProduct(data))
      throw new Error(
        "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
      );
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured2, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil, Shopee ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured2,
      draft: { ...captured2.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/shared/money.ts
  function discountPercentage(current, original) {
    if (current === null || original === null || original <= current) return null;
    const before = Math.round(original * 100), now = Math.round(current * 100);
    return before > now ? Math.round((before - now) / before * 1e4) / 100 : null;
  }
  function formatMoney(value) {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  }

  // src/popup/view.ts
  function element(id, type) {
    const node = document.getElementById(id);
    if (!(node instanceof type))
      throw new Error("Elemento da extens\xE3o n\xE3o encontrado: " + id);
    return node;
  }
  var controls = {
    configureShortcut: element("configure-shortcut", HTMLButtonElement),
    quick: element("quick", HTMLButtonElement),
    capture: element("capture", HTMLButtonElement),
    open: element("open", HTMLButtonElement)
  };
  var shortcut = element("shortcut", HTMLParagraphElement);
  var status = element("status", HTMLParagraphElement);
  var preview = element("preview", HTMLElement);
  var title = element("title", HTMLHeadingElement);
  var summary = element("summary", HTMLParagraphElement);
  var warnings = element("warnings", HTMLUListElement);
  var affiliate = element("affiliate", HTMLInputElement);
  var coupon = element("coupon", HTMLInputElement);
  var destination = element("destination", HTMLSelectElement);
  function showStatus(message, error = false) {
    status.textContent = message;
    status.dataset.error = String(error);
  }
  function resetPreview() {
    preview.hidden = true;
    affiliate.value = "";
    coupon.value = "";
  }
  function showProduct(data) {
    title.textContent = data.draft.title || "Produto sem t\xEDtulo";
    const { currentPrice: current, originalPrice: original } = data.draft;
    const discount = discountPercentage(current, original);
    let prices = current === null ? "Pre\xE7o n\xE3o encontrado" : "Por " + formatMoney(current);
    if (current !== null && original !== null && discount !== null)
      prices = "De " + formatMoney(original) + " por " + formatMoney(current) + " \xB7 " + discount.toLocaleString("pt-BR") + "% de desconto";
    summary.textContent = prices + " \xB7 " + data.draft.imageUrls.length + " imagem(ns)";
    warnings.replaceChildren();
    for (const warning of data.warnings) {
      const item = document.createElement("li");
      item.textContent = warning;
      warnings.append(item);
    }
    affiliate.value = "";
    coupon.value = "";
    preview.hidden = false;
  }
  function importOptions() {
    return {
      destination: destination.value,
      affiliateUrl: affiliate.value,
      couponCode: coupon.value
    };
  }
  function setBusy(busy) {
    controls.quick.disabled = busy;
    controls.capture.disabled = busy;
    controls.open.disabled = busy;
  }
  function showShortcut(value) {
    shortcut.textContent = value ? "Atalho: " + value + " \u2014 abre o PromoFlow publicado." : "Atalho n\xE3o configurado. Defina em chrome://extensions/shortcuts.";
  }

  // src/popup/index.ts
  var captured = null;
  async function capture(openImmediately) {
    captured = null;
    resetPreview();
    setBusy(true);
    showStatus("Lendo os dados do produto aberto\u2026");
    try {
      captured = await captureActiveProduct();
      showProduct(captured);
      if (openImmediately) {
        await openDraft(captured, importOptions());
        showStatus(
          "Rascunho aberto no PromoFlow. Confira os dados antes de salvar."
        );
      } else showStatus("Dados capturados. Revise no PromoFlow antes de salvar.");
      await chrome.action.setBadgeText({ text: "" });
      await chrome.action.setTitle({
        title: "Importar produto para o PromoFlow"
      });
    } catch (error) {
      showStatus(errorMessage(error, "Falha ao capturar a p\xE1gina."), true);
    } finally {
      setBusy(false);
    }
  }
  controls.quick.addEventListener("click", () => {
    void capture(true);
  });
  controls.capture.addEventListener("click", () => {
    void capture(false);
  });
  controls.open.addEventListener("click", async () => {
    if (!captured) return;
    setBusy(true);
    try {
      await openDraft(captured, importOptions());
      showStatus(
        "Rascunho aberto no PromoFlow. Revise e escolha o grupo para salvar."
      );
    } catch (error) {
      showStatus(
        errorMessage(error, "N\xE3o foi poss\xEDvel abrir o PromoFlow."),
        true
      );
    } finally {
      setBusy(false);
    }
  });
  void chrome.commands.getAll().then(
    (commands) => showShortcut(
      commands.find((command) => command.name === "capture-product")?.shortcut
    )
  ).catch(() => showShortcut(void 0));
  void chrome.action.getTitle({}).then((title2) => {
    if (title2.startsWith("Falha ao importar:")) showStatus(title2, true);
  }).catch(() => void 0);
  controls.configureShortcut.addEventListener("click", () => {
    void chrome.tabs.create({ url: "chrome://extensions/shortcuts" }).catch(
      (error) => showStatus(
        errorMessage(
          error,
          "Abra chrome://extensions/shortcuts para configurar o atalho."
        ),
        true
      )
    );
  });
})();
