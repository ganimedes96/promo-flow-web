"use strict";
(() => {
  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/services/account.ts
  var apiFor = (destination) => {
    if (!DESTINATIONS.includes(destination))
      throw new Error("Ambiente inv\xE1lido.");
    return destination + "/api/extension-auth";
  };
  async function requestAccount(destination, action, options = {}) {
    const response = await fetch(apiFor(destination) + "/" + action, {
      ...options,
      credentials: "omit",
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(2e4)
    }).catch(() => {
      throw new Error(
        destination === "http://localhost:3000" ? "N\xE3o foi poss\xEDvel acessar o PromoFlow local. Inicie o frontend em localhost:3000 e recarregue a extens\xE3o." : "N\xE3o foi poss\xEDvel acessar o PromoFlow. Verifique sua conex\xE3o e tente novamente."
      );
    });
    if (!response.ok && response.status !== 401) {
      const payload = await response.json().catch(() => null);
      const message = typeof payload === "object" && payload !== null && "message" in payload && typeof payload.message === "string" ? payload.message : "";
      throw new Error(
        response.status === 404 ? "O frontend ainda n\xE3o tem a conex\xE3o atualizada da extens\xE3o. Atualize ou reinicie o PromoFlow e tente novamente." : message || "N\xE3o foi poss\xEDvel consultar o PromoFlow. Tente novamente."
      );
    }
    return response;
  }
  var key = (destination) => "connection:" + destination;
  async function getAccount(destination) {
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    if (!stored) return null;
    if (new Date(stored.expiresAt).getTime() <= Date.now()) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    const response = await requestAccount(destination, "me", {
      headers: { Authorization: "Bearer " + stored.token },
      cache: "no-store"
    });
    if (response.status === 401) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    if (!response.ok)
      throw new Error("N\xE3o foi poss\xEDvel consultar sua conex\xE3o. Tente novamente.");
    const payload = await response.json();
    return payload.data.user;
  }
  var random = () => Array.from(
    crypto.getRandomValues(new Uint8Array(32)),
    (v) => v.toString(16).padStart(2, "0")
  ).join("");
  async function connectAccount(destination) {
    apiFor(destination);
    const verifier = random(), state = random();
    const digest = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(verifier)
    );
    const challenge = btoa(String.fromCharCode(...new Uint8Array(digest))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const redirectUri = chrome.identity.getRedirectURL("promoflow");
    const url = new URL(destination + "/extension/connect");
    url.searchParams.set("challenge", challenge);
    url.searchParams.set("state", state);
    url.searchParams.set("redirectUri", redirectUri);
    const callback = await chrome.identity.launchWebAuthFlow({
      url: url.toString(),
      interactive: true
    });
    if (!callback) throw new Error("Conex\xE3o cancelada.");
    const returned = new URL(callback);
    if (returned.origin !== new URL(redirectUri).origin || returned.pathname !== "/promoflow")
      throw new Error("Retorno da conex\xE3o inv\xE1lido.");
    const params = new URLSearchParams(returned.hash.slice(1));
    if (params.get("state") !== state) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    if (params.get("error") === "access_denied")
      throw new Error("Conex\xE3o cancelada.");
    if (!params.get("code")) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    const response = await requestAccount(destination, "exchange", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: params.get("code"),
        challenge,
        verifier,
        redirectUri
      })
    });
    if (!response.ok)
      throw new Error("A autoriza\xE7\xE3o expirou. Conecte novamente.");
    const result = await response.json();
    if (!/^[a-f0-9]{64}$/.test(result.data.token))
      throw new Error("Resposta de conex\xE3o inv\xE1lida.");
    await chrome.storage.local.set({ [key(destination)]: result.data });
  }
  async function getPreferences() {
    const saved = (await chrome.storage.local.get("importPreferences")).importPreferences;
    return {
      destination: saved?.destination && DESTINATIONS.includes(saved.destination) ? saved.destination : DESTINATIONS[0],
      target: saved?.target === "central" ? "central" : "offer"
    };
  }

  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host) || isShopeeHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || [
        "meli.la",
        "www.meli.la",
        "amzn.to",
        "a.co",
        "shope.ee",
        "shp.ee"
      ].some(
        (domain) => url.hostname === domain || url.hostname.endsWith("." + domain)
      ));
    } catch {
      return false;
    }
  }

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return (draft.sourceCategory === void 0 || typeof draft.sourceCategory === "string" && draft.sourceCategory.length <= 300) && typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre, na Amazon Brasil ou na Shopee."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector.js"]
    });
    const data = injection?.result;
    if (!isCapturedProduct(data))
      throw new Error(
        "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
      );
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const account = await getAccount(options.destination);
    if (!account)
      throw new Error("Conecte sua conta pelo bot\xE3o Conectar ao PromoFlow.");
    if (options.target === "central" && account.role !== "admin")
      throw new Error("A central \xE9 exclusiva do administrador.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil, Shopee ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured,
      accountId: account.id,
      target: options.target || "offer",
      draft: { ...captured.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/background/index.ts
  var capturing = false;
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "capture-product" || capturing) return;
    capturing = true;
    void (async () => {
      try {
        await chrome.action.setBadgeText({ text: "..." });
        const product = await captureActiveProduct(tab);
        await openDraft(product, {
          ...await getPreferences(),
          affiliateUrl: "",
          couponCode: ""
        });
        await chrome.action.setBadgeText({ text: "" });
        await chrome.action.setTitle({
          title: "Importar produto para o PromoFlow"
        });
      } catch (error) {
        await chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
        await chrome.action.setBadgeText({ text: "!" });
        await chrome.action.setTitle({
          title: "Falha ao importar: " + errorMessage(error, "Abra um produto e tente novamente.").slice(
            0,
            220
          )
        });
      } finally {
        capturing = false;
      }
    })().catch((error) => {
      capturing = false;
      console.error(errorMessage(error, "Falha ao importar produto."));
    });
  });
  void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  var connecting = false;
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html"))
      return false;
    if (typeof message !== "object" || message === null || !("type" in message) || message.type !== "CONNECT_ACCOUNT" || !("destination" in message) || typeof message.destination !== "string")
      return false;
    if (connecting) {
      respond({ ok: false, error: "J\xE1 existe uma conex\xE3o em andamento." });
      return false;
    }
    connecting = true;
    void connectAccount(message.destination).then(() => respond({ ok: true })).catch(
      (error) => respond({
        ok: false,
        error: errorMessage(error, "N\xE3o foi poss\xEDvel conectar.")
      })
    ).finally(() => {
      connecting = false;
    });
    return true;
  });
})();
