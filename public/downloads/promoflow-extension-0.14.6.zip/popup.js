"use strict";
(() => {
  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/services/account.ts
  var apiFor = (destination2) => {
    if (!DESTINATIONS.includes(destination2))
      throw new Error("Ambiente inv\xE1lido.");
    return destination2 + "/api/extension-auth";
  };
  async function requestAccount(destination2, action, options = {}) {
    const response = await fetch(apiFor(destination2) + "/" + action, {
      ...options,
      credentials: "omit",
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(2e4)
    }).catch(() => {
      throw new Error(
        destination2 === "http://localhost:3000" ? "N\xE3o foi poss\xEDvel acessar o PromoFlow local. Inicie o frontend em localhost:3000 e recarregue a extens\xE3o." : "N\xE3o foi poss\xEDvel acessar o PromoFlow. Verifique sua conex\xE3o e tente novamente."
      );
    });
    if (!response.ok && response.status !== 401) {
      const payload = await response.json().catch(() => null);
      const message = typeof payload === "object" && payload !== null && "message" in payload && typeof payload.message === "string" ? payload.message : "";
      throw new Error(
        response.status === 404 ? "O frontend ainda n\xE3o tem a conex\xE3o atualizada da extens\xE3o. Atualize ou reinicie o PromoFlow e tente novamente." : message || "N\xE3o foi poss\xEDvel consultar o PromoFlow. Tente novamente."
      );
    }
    return response;
  }
  var key = (destination2) => "connection:" + destination2;
  async function getAccount(destination2) {
    const stored = (await chrome.storage.local.get(key(destination2)))[key(destination2)];
    if (!stored) return null;
    if (new Date(stored.expiresAt).getTime() <= Date.now()) {
      await chrome.storage.local.remove(key(destination2));
      return null;
    }
    const response = await requestAccount(destination2, "me", {
      headers: { Authorization: "Bearer " + stored.token },
      cache: "no-store"
    });
    if (response.status === 401) {
      await chrome.storage.local.remove(key(destination2));
      return null;
    }
    if (!response.ok)
      throw new Error("N\xE3o foi poss\xEDvel consultar sua conex\xE3o. Tente novamente.");
    const payload = await response.json();
    return payload.data.user;
  }
  async function disconnectAccount(destination2) {
    const stored = (await chrome.storage.local.get(key(destination2)))[key(destination2)];
    if (stored) {
      const response = await requestAccount(destination2, "current", {
        method: "DELETE",
        headers: { Authorization: "Bearer " + stored.token }
      });
      if (!response.ok && response.status !== 401)
        throw new Error("N\xE3o foi poss\xEDvel revogar a conex\xE3o. Tente novamente.");
    }
    await chrome.storage.local.remove(key(destination2));
  }
  async function getPreferences() {
    const saved = (await chrome.storage.local.get("importPreferences")).importPreferences;
    return {
      destination: saved?.destination && DESTINATIONS.includes(saved.destination) ? saved.destination : DESTINATIONS[0],
      target: saved?.target === "central" ? "central" : "offer"
    };
  }
  async function savePreferences(preferences) {
    await chrome.storage.local.set({ importPreferences: preferences });
  }

  // src/shared/money.ts
  function discountPercentage(current, original) {
    if (current === null || original === null || original <= current) return null;
    const before = Math.round(original * 100), now = Math.round(current * 100);
    return before > now ? Math.round((before - now) / before * 1e4) / 100 : null;
  }
  function formatMoney(value) {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(value);
  }

  // src/popup/view.ts
  function element(id, type) {
    const node = document.getElementById(id);
    if (!(node instanceof type))
      throw new Error("Elemento da extens\xE3o n\xE3o encontrado: " + id);
    return node;
  }
  var controls = {
    configureShortcut: element("configure-shortcut", HTMLButtonElement),
    quick: element("quick", HTMLButtonElement),
    capture: element("capture", HTMLButtonElement),
    open: element("open", HTMLButtonElement)
  };
  var shortcut = element("shortcut", HTMLParagraphElement);
  var status = element("status", HTMLParagraphElement);
  var preview = element("preview", HTMLElement);
  var title = element("title", HTMLHeadingElement);
  var summary = element("summary", HTMLParagraphElement);
  var warnings = element("warnings", HTMLUListElement);
  var affiliate = element("affiliate", HTMLInputElement);
  var coupon = element("coupon", HTMLInputElement);
  var destination = element("destination", HTMLSelectElement);
  var importTarget = element("import-target", HTMLSelectElement);
  function showStatus(message, error = false) {
    status.hidden = false;
    status.setAttribute("role", error ? "alert" : "status");
    status.textContent = message;
    status.dataset.error = String(error);
    if (error) status.scrollIntoView({ block: "nearest" });
  }
  function resetPreview() {
    preview.hidden = true;
    affiliate.value = "";
    coupon.value = "";
  }
  function showProduct(data) {
    title.textContent = data.draft.title || "Produto sem t\xEDtulo";
    const { currentPrice: current, originalPrice: original } = data.draft;
    const discount = discountPercentage(current, original);
    let prices = current === null ? "Pre\xE7o n\xE3o encontrado" : "Por " + formatMoney(current);
    if (current !== null && original !== null && discount !== null)
      prices = "De " + formatMoney(original) + " por " + formatMoney(current) + " \xB7 " + discount.toLocaleString("pt-BR") + "% de desconto";
    summary.textContent = prices + " \xB7 " + data.draft.imageUrls.length + " imagem(ns)";
    warnings.replaceChildren();
    for (const warning of data.warnings) {
      const item = document.createElement("li");
      item.textContent = warning;
      warnings.append(item);
    }
    affiliate.value = "";
    coupon.value = "";
    preview.hidden = false;
  }
  function importOptions() {
    return {
      destination: destination.value,
      target: importTarget.value === "central" ? "central" : "offer",
      affiliateUrl: affiliate.value,
      couponCode: coupon.value
    };
  }
  function setBusy(busy) {
    controls.quick.disabled = busy;
    controls.capture.disabled = busy;
    controls.open.disabled = busy;
  }
  function showShortcut(value) {
    shortcut.textContent = value ? "Atalho: " + value + " \u2014 usa o ambiente selecionado." : "Atalho n\xE3o configurado. Defina em chrome://extensions/shortcuts.";
  }

  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host) || isShopeeHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || [
        "meli.la",
        "www.meli.la",
        "amzn.to",
        "a.co",
        "shope.ee",
        "shp.ee"
      ].some(
        (domain) => url.hostname === domain || url.hostname.endsWith("." + domain)
      ));
    } catch {
      return false;
    }
  }

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return (draft.sourceCategory === void 0 || typeof draft.sourceCategory === "string" && draft.sourceCategory.length <= 300) && (draft.affiliateCommissionRate === void 0 || typeof draft.affiliateCommissionRate === "number" && Number.isFinite(draft.affiliateCommissionRate) && draft.affiliateCommissionRate >= 0 && draft.affiliateCommissionRate <= 100) && typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre, na Amazon Brasil ou na Shopee."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const read = async () => {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["collector.js"]
      });
      const data2 = injection?.result;
      if (!isCapturedProduct(data2))
        throw new Error(
          "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
        );
      return data2;
    };
    let data = await read();
    if (isShopeeHost(new URL(tab.url).hostname) && data.draft.currentPrice === null) {
      const identity = (url) => new URL(url).pathname.match(/(?:-i\.|\/product\/)(\d+)[./](\d+)/)?.slice(1).join(":");
      const initial = identity(data.draft.sourceUrl);
      for (let attempt = 0; attempt < 3 && data.draft.currentPrice === null; attempt++) {
        await new Promise((resolve) => setTimeout(resolve, 800));
        const next = await read();
        if (!initial || identity(next.draft.sourceUrl) !== initial)
          throw new Error(
            "O produto mudou durante a captura. Capture novamente o an\xFAncio desejado."
          );
        data = next;
      }
    }
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured2, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const account = await getAccount(options.destination);
    if (!account)
      throw new Error("Conecte sua conta pelo bot\xE3o Conectar ao PromoFlow.");
    if (options.target === "central" && account.role !== "admin")
      throw new Error("A central \xE9 exclusiva do administrador.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil, Shopee ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured2,
      accountId: account.id,
      target: options.target || "offer",
      draft: { ...captured2.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/popup/index.ts
  var captured = null;
  async function capture(openImmediately) {
    captured = null;
    resetPreview();
    setBusy(true);
    showStatus("Lendo os dados do produto aberto\u2026");
    try {
      captured = await captureActiveProduct();
      showProduct(captured);
      if (openImmediately) {
        await openDraft(captured, importOptions());
        showStatus(
          "Rascunho aberto no PromoFlow. Confira os dados antes de salvar."
        );
      } else showStatus("Dados capturados. Revise no PromoFlow antes de salvar.");
      await chrome.action.setBadgeText({ text: "" });
      await chrome.action.setTitle({
        title: "Importar produto para o PromoFlow"
      });
    } catch (error) {
      showStatus(errorMessage(error, "Falha ao capturar a p\xE1gina."), true);
    } finally {
      setBusy(false);
    }
  }
  controls.quick.addEventListener("click", () => {
    void capture(true);
  });
  controls.capture.addEventListener("click", () => {
    void capture(false);
  });
  controls.open.addEventListener("click", async () => {
    if (!captured) return;
    setBusy(true);
    try {
      await openDraft(captured, importOptions());
      showStatus(
        "Rascunho aberto no PromoFlow. Revise e escolha o grupo para salvar."
      );
    } catch (error) {
      showStatus(
        errorMessage(error, "N\xE3o foi poss\xEDvel abrir o PromoFlow."),
        true
      );
    } finally {
      setBusy(false);
    }
  });
  void chrome.commands.getAll().then(
    (commands) => showShortcut(
      commands.find((command) => command.name === "capture-product")?.shortcut
    )
  ).catch(() => showShortcut(void 0));
  void chrome.action.getTitle({}).then((title2) => {
    if (title2.startsWith("Falha ao importar:")) showStatus(title2, true);
  }).catch(() => void 0);
  controls.configureShortcut.addEventListener("click", () => {
    void chrome.tabs.create({ url: "chrome://extensions/shortcuts" }).catch(
      (error) => showStatus(
        errorMessage(
          error,
          "Abra chrome://extensions/shortcuts para configurar o atalho."
        ),
        true
      )
    );
  });
  var accountStatus = document.getElementById(
    "account-status"
  );
  var connectButton = document.getElementById(
    "connect-account"
  );
  var disconnectButton = document.getElementById(
    "disconnect-account"
  );
  var accountBadge = document.getElementById(
    "account-badge"
  );
  var accountRefresh = 0;
  async function refreshAccount() {
    const version = ++accountRefresh;
    accountBadge.textContent = "Verificando";
    try {
      const account = await getAccount(destination.value);
      if (version !== accountRefresh) return;
      accountBadge.textContent = account ? "Conectado" : "N\xE3o conectado";
      accountBadge.dataset.connected = String(!!account);
      accountStatus.textContent = account ? account.name + " \xB7 " + account.email + (account.role === "admin" ? " \xB7 Administrador" : "") : "Sua conta ainda n\xE3o est\xE1 conectada.";
      connectButton.hidden = !!account;
      disconnectButton.hidden = !account;
      const central = importTarget.querySelector(
        'option[value="central"]'
      );
      central.hidden = account?.role !== "admin";
      central.disabled = account?.role !== "admin";
      if (account?.role !== "admin") importTarget.value = "offer";
    } catch (error) {
      if (version !== accountRefresh) return;
      accountBadge.textContent = "Sem comunica\xE7\xE3o";
      accountBadge.dataset.connected = "false";
      accountStatus.textContent = "N\xE3o foi poss\xEDvel verificar sua conta.";
      showStatus(
        errorMessage(error, "N\xE3o foi poss\xEDvel consultar a conex\xE3o."),
        true
      );
      importTarget.value = "offer";
    }
  }
  var persistPreferences = () => savePreferences({
    destination: destination.value,
    target: importTarget.value === "central" ? "central" : "offer"
  });
  destination.addEventListener("change", () => {
    void refreshAccount();
    void persistPreferences();
  });
  importTarget.addEventListener("change", () => {
    void persistPreferences();
  });
  connectButton.addEventListener("click", () => {
    connectButton.disabled = true;
    showStatus("Conclua o login e autorize a conex\xE3o na janela do PromoFlow.");
    void chrome.runtime.sendMessage({ type: "CONNECT_ACCOUNT", destination: destination.value }).then((response) => {
      if (!response.ok) throw new Error(response.error || "Conex\xE3o cancelada.");
      void refreshAccount();
      showStatus("Conta conectada.");
    }).catch(
      (error) => showStatus(errorMessage(error, "N\xE3o foi poss\xEDvel conectar."), true)
    ).finally(() => {
      connectButton.disabled = false;
    });
  });
  disconnectButton.addEventListener("click", () => {
    disconnectButton.disabled = true;
    void disconnectAccount(destination.value).then(() => refreshAccount()).catch(
      (error) => showStatus(errorMessage(error, "N\xE3o foi poss\xEDvel desconectar."), true)
    ).finally(() => {
      disconnectButton.disabled = false;
    });
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes["connection:" + destination.value])
      void refreshAccount();
  });
  void getPreferences().then((preferences) => {
    destination.value = preferences.destination;
    importTarget.value = preferences.target;
    return refreshAccount();
  }).catch(() => {
    accountStatus.textContent = "N\xE3o foi poss\xEDvel carregar a conex\xE3o.";
  });
})();
