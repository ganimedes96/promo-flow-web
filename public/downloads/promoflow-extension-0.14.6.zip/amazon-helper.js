"use strict";
(() => {
  // src/affiliate/amazon/links.ts
  function amazonLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const u = new URL(value);
      return u.protocol === "https:" && !u.username && !u.password && !u.port && ["amazon.com.br", "www.amazon.com.br", "amzn.to", "a.co"].includes(u.hostname);
    } catch {
      return false;
    }
  }
  function amazonAsin(value) {
    if (!amazonLink(value)) return null;
    const u = new URL(value);
    if (!["amazon.com.br", "www.amazon.com.br"].includes(u.hostname)) return null;
    return u.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([a-z0-9]{10})(?:\/|$)/i)?.[1].toUpperCase() ?? null;
  }
  function amazonAffiliate(value, tag, asin) {
    if (!amazonLink(value)) return false;
    const u = new URL(value), found = amazonAsin(value), tags = u.searchParams.getAll("tag");
    return !!found && tags.length === 1 && /^[a-z0-9_-]{3,80}$/i.test(tags[0]) && (!tag || tags[0] === tag) && (!asin || found === asin);
  }

  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }

  // src/collector/amazon/sitestripe.ts
  function readAmazonSiteStripe(doc) {
    const docs = [doc];
    for (const frame of Array.from(doc.querySelectorAll("iframe"))) {
      try {
        if (frame.contentDocument) docs.push(frame.contentDocument);
      } catch {
      }
    }
    for (const current of docs) {
      const text = (current.body?.textContent || "").replace(/\s+/g, " ");
      if (!/sitestripe/i.test(text) || !/taxas? de comiss[aã]o/i.test(text)) continue;
      const labels = Array.from(current.querySelectorAll("span,div,label,p")).filter((el) => el.children.length === 0);
      const valueAfter = (pattern) => {
        const matching = labels.filter((el) => pattern.test((el.textContent || "").trim()));
        if (matching.length !== 1) return void 0;
        let node = matching[0];
        for (let depth = 0; depth < 3 && node; depth++, node = node.parentElement) {
          const sibling = node.nextElementSibling;
          const value = sibling?.textContent?.replace(/\s+/g, " ").trim();
          if (value && value.length <= 120) return value;
        }
        return void 0;
      };
      const category = valueAfter(/^categoria$/i);
      const rateText = valueAfter(/^taxas? de comiss[aã]o$/i);
      const match = rateText?.match(/^(\d{1,3})(?:[,.](\d{1,2}))?\s*%$/);
      const rate = match ? Number(match[1] + "." + (match[2] || "0")) : void 0;
      return {
        ...category && !/%|comiss[aã]o/i.test(category) ? { category: category.slice(0, 120) } : {},
        ...rate !== void 0 && rate >= 0 && rate <= 100 ? { commissionRate: rate } : {}
      };
    }
    return {};
  }

  // src/affiliate/amazon-helper.ts
  async function start() {
    const context = await chrome.runtime.sendMessage({ type: "AMAZON_CONTEXT" }).catch(() => null);
    if (!isRecord(context) || context.ok !== true || !validRequestId(context.requestId) || typeof context.tag !== "string" || typeof context.expiresAt !== "number") return;
    const requestId = context.requestId, tag = context.tag;
    const send = (type, data = {}) => chrome.runtime.sendMessage({ type, requestId, ...data });
    const fail = async (message) => {
      await send("AMAZON_FAILED", { message }).catch(() => void 0);
    };
    const asin = amazonAsin(location.href);
    if (!asin) {
      await fail(/\/ap\/(?:signin|login)/i.test(location.pathname) || document.querySelector('input[type="password"]') ? "Entre na conta de associado da Amazon neste navegador." : "Abra uma p\xE1gina de produto da Amazon para converter.");
      return;
    }
    const root = document.body;
    const visible = (el) => el.getClientRects().length > 0;
    const named = (el) => (el.getAttribute("aria-label") || el.textContent || "").replace(/\s+/g, " ").trim();
    const normalized = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toLocaleLowerCase("pt-BR");
    const buttonFor = (el) => el.closest("button,a,[role=button],label") || el;
    const matching = (text) => {
      const wanted = normalized(text);
      const controls = Array.from(root.querySelectorAll("button,a,[role=button],label,input[type=button],input[type=submit]")).filter(visible).filter((el) => {
        const value = normalized(named(el) || (el instanceof HTMLInputElement ? el.value : ""));
        return value === wanted || value.includes(wanted);
      });
      if (controls.length) return [...new Set(controls)];
      return [...new Set(Array.from(root.querySelectorAll("span,div")).filter(visible).filter((el) => normalized(named(el)) === wanted).map(buttonFor).filter(visible))];
    };
    const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    try {
      for (let i = 0; i < 60 && matching("Obter link").length === 0; i++) await wait(250);
      const open = matching("Obter link");
      if (open.length !== 1) throw new Error("A SiteStripe n\xE3o apareceu. Entre na conta de associado e ative a barra na Amazon.");
      open[0].click();
      for (let i = 0; i < 60 && matching("Copiar link de associado").length === 0; i++) await wait(250);
      const copy = matching("Copiar link de associado");
      if (copy.length !== 1) throw new Error("N\xE3o foi poss\xEDvel abrir a gera\xE7\xE3o de links da Amazon.");
      const candidates = Array.from(root.querySelectorAll("select")).filter(visible).filter((el) => {
        const label = el.labels?.[0]?.textContent || el.getAttribute("aria-label") || el.parentElement?.textContent || "";
        return /rastreamento/i.test(label);
      });
      if (candidates.length !== 1) throw new Error("N\xE3o foi poss\xEDvel confirmar o ID de rastreamento na SiteStripe.");
      const tracking = candidates[0], selected = tracking.selectedOptions[0];
      if (!selected || selected.value !== tag && selected.textContent?.trim() !== tag) throw new Error("O ID de rastreamento da Amazon n\xE3o corresponde ao cadastrado em Lojas.");
      const full = matching("Link completo");
      if (full.length !== 1) throw new Error("Selecione o formato de link completo na SiteStripe.");
      full[0].click();
      await wait(300);
      const watch = await send("AMAZON_WATCH");
      if (!isRecord(watch) || watch.ok !== true) throw new Error("N\xE3o foi poss\xEDvel acompanhar o link gerado.");
      const result = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          window.removeEventListener("message", receive);
          reject(new Error("A Amazon n\xE3o retornou o link automaticamente."));
        }, 1e4);
        const receive = (event) => {
          if (event.source !== window || event.origin !== location.origin || !isRecord(event.data) || event.data.type !== "PROMOFLOW_AMAZON_COPIED" || event.data.requestId !== requestId || !amazonAffiliate(event.data.value, tag, asin)) return;
          clearTimeout(timer);
          window.removeEventListener("message", receive);
          resolve(event.data.value);
        };
        window.addEventListener("message", receive);
      });
      copy[0].click();
      const link = await result;
      const stripe = readAmazonSiteStripe(document);
      const done = await send("AMAZON_COMPLETE", { affiliateUrl: link, ...stripe.category ? { sourceCategory: stripe.category } : {}, ...stripe.commissionRate !== void 0 ? { affiliateCommissionRate: stripe.commissionRate } : {} });
      if (!isRecord(done) || done.ok !== true) throw new Error("N\xE3o foi poss\xEDvel devolver o link ao PromoFlow.");
    } catch (error) {
      await fail(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel converter o link da Amazon.");
    }
  }
  void start();
})();
