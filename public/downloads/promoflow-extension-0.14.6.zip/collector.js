"use strict";
var PromoFlowCapture = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/collector/index.ts
  var index_exports = {};
  __export(index_exports, {
    result: () => result
  });

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function cleanText(value, max) {
    return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
  }

  // src/collector/shared/metadata.ts
  function structuredProduct() {
    const queue = [];
    for (const script of [
      ...document.querySelectorAll('script[type="application/ld+json"]')
    ].slice(0, LIMITS.jsonScripts)) {
      const raw = script.textContent || "";
      if (raw.length > LIMITS.jsonScript) continue;
      try {
        const value = JSON.parse(raw);
        queue.push(value);
      } catch {
      }
    }
    let count = 0;
    while (queue.length && count++ < LIMITS.metadataNodes) {
      const node = queue.shift();
      if (Array.isArray(node)) {
        queue.push(...node.slice(0, 100));
        continue;
      }
      if (!isRecord(node)) continue;
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      if (types.some(
        (type) => typeof type === "string" && /(?:^|[/#])Product$/.test(type)
      ))
        return node;
      for (const key of ["@graph", "mainEntity", "itemListElement", "item"])
        if (node[key]) queue.push(node[key]);
    }
    return void 0;
  }

  // src/collector/shared/category.ts
  function readSourceCategory(title) {
    const normalize = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
    const ignored = /* @__PURE__ */ new Set([
      "inicio",
      "home",
      "shopee",
      "shopee brasil",
      "mercado livre",
      "amazon",
      "amazon brasil",
      normalize(title)
    ]);
    const join = (parts) => {
      const values = parts.filter((part) => typeof part === "string").map((part) => cleanText(part, 120)).filter((part) => part && !ignored.has(normalize(part)));
      return [...new Set(values)].join(" > ").slice(0, 300) || void 0;
    };
    const selectors = '#wayfinding-breadcrumbs_feature_div a, .andes-breadcrumb a, [data-testid*="breadcrumb"] a, [data-sqe="breadcrumb"] a, [aria-label*="breadcrumb" i] a, [aria-label="Trilha de navega\xE7\xE3o" i] a, [aria-label="Caminho de navega\xE7\xE3o" i] a, [class*="breadcrumb" i] a';
    const links = [...document.querySelectorAll(selectors)].slice(0, 40).filter((node) => node.getClientRects().length > 0);
    const visible2 = join(links.map((node) => node.textContent));
    if (visible2) return visible2;
    const queue = [];
    for (const script of [
      ...document.querySelectorAll('script[type="application/ld+json"]')
    ].slice(0, LIMITS.jsonScripts)) {
      if ((script.textContent?.length ?? 0) > LIMITS.jsonScript) continue;
      try {
        queue.push(JSON.parse(script.textContent || ""));
      } catch {
      }
    }
    for (let count = 0; queue.length && count < LIMITS.metadataNodes; count++) {
      const node = queue.shift();
      if (Array.isArray(node)) {
        queue.push(...node.slice(0, 100));
        continue;
      }
      if (!isRecord(node)) continue;
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      if (types.some(
        (type) => typeof type === "string" && /(?:^|[/#])BreadcrumbList$/.test(type)
      ) && Array.isArray(node.itemListElement)) {
        const trail = node.itemListElement.filter(isRecord).sort((a, b) => Number(a.position ?? 0) - Number(b.position ?? 0));
        const category2 = join(
          trail.map(
            (item) => item.name ?? (isRecord(item.item) ? item.item.name : void 0)
          )
        );
        if (category2) return category2;
      }
      if (node["@graph"]) queue.push(node["@graph"]);
    }
    const category = structuredProduct()?.category;
    return join(Array.isArray(category) ? category : [category]);
  }

  // src/collector/amazon/sitestripe.ts
  function readAmazonSiteStripe(doc) {
    const docs = [doc];
    for (const frame of Array.from(doc.querySelectorAll("iframe"))) {
      try {
        if (frame.contentDocument) docs.push(frame.contentDocument);
      } catch {
      }
    }
    for (const current of docs) {
      const text = (current.body?.textContent || "").replace(/\s+/g, " ");
      if (!/sitestripe/i.test(text) || !/taxas? de comiss[aã]o/i.test(text)) continue;
      const labels = Array.from(current.querySelectorAll("span,div,label,p")).filter((el) => el.children.length === 0);
      const valueAfter = (pattern) => {
        const matching = labels.filter((el) => pattern.test((el.textContent || "").trim()));
        if (matching.length !== 1) return void 0;
        let node = matching[0];
        for (let depth = 0; depth < 3 && node; depth++, node = node.parentElement) {
          const sibling = node.nextElementSibling;
          const value = sibling?.textContent?.replace(/\s+/g, " ").trim();
          if (value && value.length <= 120) return value;
        }
        return void 0;
      };
      const category = valueAfter(/^categoria$/i);
      const rateText = valueAfter(/^taxas? de comiss[aã]o$/i);
      const match = rateText?.match(/^(\d{1,3})(?:[,.](\d{1,2}))?\s*%$/);
      const rate = match ? Number(match[1] + "." + (match[2] || "0")) : void 0;
      return {
        ...category && !/%|comiss[aã]o/i.test(category) ? { category: category.slice(0, 120) } : {},
        ...rate !== void 0 && rate >= 0 && rate <= 100 ? { commissionRate: rate } : {}
      };
    }
    return {};
  }

  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function largerImage(url) {
    if (url.hostname !== "http2.mlstatic.com") return url.href;
    const match = url.pathname.match(
      /^\/D_([A-Z0-9_]+)_(\d+-ML[A-Z]\d+_\d+)-([A-Z])(?:-[^/]*)?\.(?:webp|jpe?g|png)$/i
    );
    if (!match || match[1].startsWith("NQ_NP") && ["O", "F"].includes(match[3]))
      return url.href;
    return "https://http2.mlstatic.com/D_NQ_NP_" + match[2] + "-O.webp";
  }

  // src/collector/shared/dom.ts
  function visible(selector) {
    return [...document.querySelectorAll(selector)].find(
      (node) => node.getClientRects().length > 0 && getComputedStyle(node).visibility !== "hidden"
    );
  }
  function meta(key) {
    return [...document.querySelectorAll("meta")].find(
      (node) => (node.getAttribute("property") || node.getAttribute("name") || "").toLowerCase() === key
    )?.content;
  }

  // src/shared/money.ts
  function parseMoney(value) {
    if (typeof value !== "number" && typeof value !== "string") return null;
    let raw = String(value).trim();
    if (raw.includes(",")) raw = raw.replace(/\./g, "").replace(",", ".");
    if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) return null;
    const result2 = Number(raw);
    return Number.isFinite(result2) && result2 > 0 && result2 <= LIMITS.price ? result2 : null;
  }

  // src/collector/shopee/price-dom.ts
  var conditional = /\d+\s*x\s*R\s*\$|parcel|frete|cashback|moedas|cupom|economize/i;
  var priceSelectors = '[data-testid*="price"], [data-sqe="price"], [itemprop="price"], [class*="price" i], [aria-label*="R$"], del, s';
  function shown(node) {
    return node.getClientRects().length > 0 && getComputedStyle(node).visibility !== "hidden";
  }
  function inPriceArea(node, heading) {
    if (!shown(node)) return false;
    if (!heading) return true;
    const bounds = node.getBoundingClientRect(), title = heading.getBoundingClientRect();
    return bounds.top >= title.top - 25 && bounds.top <= title.bottom + 420 && bounds.left >= title.left - 90;
  }
  function amount(raw) {
    return parseMoney(
      /^(?:\d{1,3}\.)+\d{3}$/.test(raw) ? raw.replace(/\./g, "") : raw
    );
  }
  function normalizePriceText(text) {
    return text.replace(/[\u200b-\u200d\ufeff]/g, "").replace(/(\d)\s*([,.])\s*(?=\d)/g, "$1$2");
  }
  function amounts(text) {
    text = normalizePriceText(text);
    return [...text.matchAll(/R\s*\$\s*([\d.]+(?:,\d{1,2})?)/g)].flatMap(
      (match) => {
        const value = amount(match[1]);
        return value === null ? [] : [value];
      }
    );
  }
  function struck(node) {
    for (let current = node, depth = 0; current && depth < 4; depth++, current = current.parentElement) {
      if (current.matches(
        'del, s, [data-testid*="original-price"], [class*="original-price"]'
      ) || getComputedStyle(current).textDecorationLine.includes("line-through"))
        return true;
    }
    return false;
  }
  function excluded(node) {
    if (node.closest(
      '[data-testid*="shipping"], [class*="shipping" i], [class*="installment" i], [class*="voucher" i], [class*="cashback" i], nav, footer'
    ))
      return true;
    const bounds = node.getBoundingClientRect();
    for (let current = node, depth = 0; current && depth < 4; depth++, current = current.parentElement) {
      const text = cleanText(current.textContent, 301);
      const area = current.getBoundingClientRect();
      if (text.length <= 180 && area.height <= Math.max(48, bounds.height * 2) && area.width <= Math.max(360, bounds.width + 180) && conditional.test(text))
        return true;
    }
    return false;
  }
  function range(node) {
    for (let current = node, depth = 0; current && depth < 3; depth++, current = current.parentElement) {
      const text = cleanText(current.textContent, 181);
      if (text.length <= 180 && /R\s*\$\s*[\d.,]+\s*(?:-|–|—|até)\s*(?:R\s*\$\s*)?[\d.,]+(?![\d.,]|\s*%)/i.test(
        text
      ))
        return true;
    }
    return false;
  }
  function candidates(heading) {
    const main = document.querySelector('main, [role="main"], .page-product');
    const root = main && (!heading || main.contains(heading)) ? main : document.body;
    const result2 = /* @__PURE__ */ new Set();
    for (const node of [...root.querySelectorAll(priceSelectors)].slice(
      0,
      LIMITS.metadataNodes
    ))
      result2.add(node);
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let count = 0; count < LIMITS.metadataNodes * 10 && result2.size < LIMITS.metadataNodes * 2; count++) {
      const text = walker.nextNode();
      if (!text) break;
      const content = normalizePriceText(cleanText(text.textContent, 80));
      const parent = text.parentElement;
      const previousAmount = parent && /^[\d.]+,\d{2}$/.test(content) && struck(parent);
      if (!/R\s*\$/.test(content) && !previousAmount || parent?.closest("script, style, noscript"))
        continue;
      for (let node = text.parentElement, depth = 0; node && depth < 5; depth++, node = node.parentElement) {
        if ((node.textContent?.length ?? 0) > 300) break;
        result2.add(node);
      }
    }
    return [...result2];
  }
  function add(target, node, value) {
    target.push({
      node,
      value,
      size: Number.parseFloat(getComputedStyle(node).fontSize) || 0
    });
  }
  function plainAmount(node) {
    const text = normalizePriceText(cleanText(node.textContent, 50));
    return /^[\d.,]+$/.test(text) ? amount(text) : null;
  }
  function findHeading(title) {
    if (!title) return void 0;
    const normalize = (text) => cleanText(text, 250).replace(/\s*[|–-]\s*Shopee(?: Brasil)?.*$/i, "").toLocaleLowerCase("pt-BR");
    const expected = normalize(title);
    if (expected.length < 10) return void 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let count = 0; count < LIMITS.metadataNodes * 10; count++) {
      const node = walker.nextNode();
      if (!node) break;
      if (node.parentElement && (normalize(node.textContent || "") === expected || normalize(node.parentElement.textContent || "") === expected) && shown(node.parentElement) && !node.parentElement.closest("script, style, nav, footer"))
        return node.parentElement;
    }
    return void 0;
  }
  function readVisibleShopeePrices(heading, title) {
    const anchor = heading ?? findHeading(title);
    const current = [], original = [];
    let hasPriceRange = false;
    for (const node of candidates(anchor)) {
      if (!inPriceArea(node, anchor) || excluded(node)) continue;
      const text = cleanText(
        node.getAttribute("aria-label") || node.textContent,
        301
      );
      if (!text || text.length > 180 || conditional.test(text)) continue;
      const values = amounts(text);
      if (struck(node)) {
        const previous2 = values.length === 1 ? values[0] : plainAmount(node);
        if (previous2 !== null) add(original, node, previous2);
        continue;
      }
      if (range(node)) {
        hasPriceRange = true;
        continue;
      }
      if (values.length === 1) {
        add(current, node, values[0]);
      } else if (values.length === 2) {
        for (const child of [...node.querySelectorAll("*")].slice(0, 60)) {
          if (!shown(child) || !struck(child)) continue;
          const previousValues = amounts(cleanText(child.textContent, 80));
          const previous2 = previousValues.length === 1 ? previousValues[0] : plainAmount(child);
          if (previous2 === null || !values.includes(previous2)) continue;
          const sale = values.find((value) => value < previous2);
          if (sale !== void 0) {
            add(current, node, sale);
            add(original, child, previous2);
          }
        }
      }
    }
    const titleBounds = anchor?.getBoundingClientRect();
    const score = (candidate) => candidate.size * 5 - (titleBounds ? Math.max(
      0,
      candidate.node.getBoundingClientRect().top - titleBounds.bottom
    ) / 12 : 0);
    current.sort((a, b) => score(b) - score(a));
    const chosen = current[0];
    const currentBounds = chosen?.node.getBoundingClientRect();
    const previous = currentBounds ? original.filter((candidate) => {
      const bounds = candidate.node.getBoundingClientRect();
      return candidate.value > chosen.value && Math.abs(bounds.top - currentBounds.top) <= 100 && Math.abs(bounds.left - currentBounds.left) <= 650;
    }).sort((a, b) => {
      const distance = (candidate) => {
        const bounds = candidate.node.getBoundingClientRect();
        return Math.abs(bounds.top - currentBounds.top) * 4 + Math.abs(bounds.left - currentBounds.right);
      };
      return distance(a) - distance(b);
    })[0] : void 0;
    return {
      currentPrice: chosen?.value ?? null,
      originalPrice: previous?.value ?? null,
      hasPriceRange: !chosen && hasPriceRange
    };
  }

  // src/collector/shopee/prices.ts
  function readShopeePrices(product, heading) {
    const visible2 = readVisibleShopeePrices(
      heading,
      typeof product?.name === "string" ? product.name : meta("og:title")
    );
    let { currentPrice, originalPrice: original, hasPriceRange } = visible2;
    const raw = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
    const offer = isRecord(raw) ? raw : {};
    const currency = String(
      offer.priceCurrency || meta("product:price:currency") || meta("og:price:currency") || ""
    ).toUpperCase();
    if (currentPrice === null && !hasPriceRange && currency === "BRL") {
      const low = parseMoney(offer.lowPrice), high = parseMoney(offer.highPrice);
      if (low !== null && high !== null && low !== high) hasPriceRange = true;
      else
        currentPrice = parseMoney(offer.price) ?? (low === high ? low : null) ?? parseMoney(meta("product:price:amount") ?? meta("og:price:amount"));
    }
    const specifications = Array.isArray(offer.priceSpecification) ? offer.priceSpecification : [offer.priceSpecification];
    if (original === null && currency === "BRL") {
      const old = specifications.find(
        (value) => isRecord(value) && typeof value.priceType === "string" && /(?:^|[/#])StrikethroughPrice$/.test(value.priceType) && (value.priceCurrency === void 0 || value.priceCurrency === "BRL")
      );
      original = parseMoney(old?.price);
    }
    return {
      currentPrice,
      originalPrice: original !== null && currentPrice !== null && original > currentPrice ? original : null,
      hasPriceRange
    };
  }

  // src/collector/shopee/images.ts
  function readShopeeImages(product, heading) {
    const images = /* @__PURE__ */ new Set();
    function add2(value) {
      if (typeof value !== "string" || !value.trim() || images.size >= LIMITS.images)
        return;
      try {
        const url = new URL(value, location.href);
        if (url.protocol !== "https:" || url.username || url.password || !isProductImageHost(url.hostname) || url.href.length > LIMITS.url)
          return;
        if (/(?:^|\.)susercontent\.com$/.test(url.hostname) || /(?:^|\.)shopee\.com\.br$/.test(url.hostname)) {
          if (!url.pathname.includes("/file/")) return;
          url.pathname = url.pathname.replace(/@resize[^/]*$/i, "").replace(/_(?:tn|t)(?=\.(?:webp|jpe?g|png)$|$)/i, "");
        }
        images.add(url.href);
      } catch {
      }
    }
    const entries = Array.isArray(product?.image) ? product.image : [product?.image];
    for (const entry of entries)
      add2(isRecord(entry) ? entry.contentUrl || entry.url : entry);
    add2(meta("og:image"));
    const selector = '[data-testid*="product-image"] img, [data-sqe="product-images"] img, main img, [role="main"] img, .page-product img';
    for (const image of [
      ...document.querySelectorAll(selector)
    ].slice(0, 150)) {
      const rect = image.getBoundingClientRect(), title = heading?.getBoundingClientRect();
      if (title && (rect.top < title.top - 450 || rect.top > title.bottom + 450))
        continue;
      if (Math.max(rect.width, image.naturalWidth) < 60 || Math.max(rect.height, image.naturalHeight) < 60)
        continue;
      const sources = (image.getAttribute("srcset") || "").split(",").map((source) => source.trim().split(/\s+/)).sort((a, b) => (parseFloat(b[1]) || 0) - (parseFloat(a[1]) || 0));
      if (sources[0]?.[0]) add2(sources[0][0]);
      add2(image.getAttribute("data-src"));
      add2(image.currentSrc || image.src);
    }
    return [...images];
  }

  // src/collector/shopee/description.ts
  function readShopeeDescription(product) {
    for (const selector of [
      '[data-testid="product-description"]',
      '[data-sqe="description"]',
      '[class*="product-description"]'
    ]) {
      const node = visible(selector), text = cleanText(node?.textContent, LIMITS.description);
      if (text) return text;
    }
    for (const heading of [...document.querySelectorAll("h2,h3")].slice(0, 80)) {
      if (!/^descri[çc][aã]o (?:do produto|do an[uú]ncio)$/i.test(
        cleanText(heading.textContent, 80)
      ))
        continue;
      const section = heading.closest("section") || heading.parentElement;
      const text = cleanText(section?.textContent, LIMITS.description).replace(
        /^descri[çc][aã]o (?:do produto|do an[uú]ncio)\s*/i,
        ""
      );
      if (text) return text;
    }
    const raw = cleanText(product?.description || meta("og:description"), 1e4);
    return cleanText(
      new DOMParser().parseFromString(raw, "text/html").body.textContent,
      LIMITS.description
    );
  }

  // src/collector/shopee/index.ts
  function captureShopeeProduct() {
    if (!isShopeeHost(location.hostname))
      throw new Error("Abra o produto na Shopee Brasil.");
    const ids = location.pathname.match(
      /(?:-i\.|\/product\/)(\d{1,20})(?:\.|\/)(\d{1,20})(?:\/|$)/i
    );
    if (!ids)
      throw new Error(
        "Abra o an\xFAncio do produto na Shopee e aguarde os links curtos redirecionarem."
      );
    const heading = visible(
      'h1, [data-testid="product-title"], [data-sqe="name"]'
    );
    const product = structuredProduct();
    const title = cleanText(
      heading?.textContent || product?.name || meta("og:title"),
      LIMITS.title
    ).replace(/\s*[|–-]\s*Shopee(?: Brasil)?.*$/i, "");
    if (!title || /^(?:entrar$|login$|fa[çc]a login|verifica[çc][aã]o|captcha|acesso negado|shopee brasil)/i.test(
      title
    ))
      throw new Error(
        "N\xE3o foi poss\xEDvel ler o produto. Conclua a navega\xE7\xE3o normal na Shopee, selecione a varia\xE7\xE3o e aguarde carregar antes de capturar."
      );
    const prices = readShopeePrices(product, heading);
    const imageUrls = readShopeeImages(product, heading);
    const description = readShopeeDescription(product);
    const source = new URL(location.href);
    source.hash = "";
    const sourceUrl = source.href.length <= LIMITS.url ? source.href : new URL(`/product/${ids[1]}/${ids[2]}`, location.origin).href;
    const warnings = [];
    if (!description)
      warnings.push("Descri\xE7\xE3o n\xE3o encontrada. Complete no PromoFlow.");
    if (!imageUrls.length)
      warnings.push("Imagem n\xE3o encontrada. Informe a imagem do produto.");
    if (prices.currentPrice === null)
      warnings.push(
        prices.hasPriceRange ? "A Shopee mostrou uma faixa de pre\xE7os. Selecione uma varia\xE7\xE3o e capture novamente ou preencha o pre\xE7o no PromoFlow." : "Pre\xE7o em reais n\xE3o encontrado. Confira a varia\xE7\xE3o e informe manualmente."
      );
    if (prices.originalPrice === null)
      warnings.push("Pre\xE7o antigo n\xE3o encontrado ou sem desconto confirmado.");
    warnings.push(
      "Confira varia\xE7\xE3o, vendedor, frete, moedas, Pix e cupons da Shopee antes de salvar. Descontos condicionais n\xE3o aplicados n\xE3o s\xE3o calculados pela extens\xE3o."
    );
    return {
      version: 1,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      draft: {
        sourceUrl,
        title,
        description,
        imageUrls,
        currentPrice: prices.currentPrice,
        originalPrice: prices.originalPrice
      },
      warnings
    };
  }

  // src/collector/mercado-livre/prices.ts
  function readPrices(product) {
    const first = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
    const offer = isRecord(first) ? first : {};
    const currency = cleanText(
      offer.priceCurrency || meta("product:price:currency"),
      10
    ).toUpperCase();
    const amount2 = (selector) => {
      const node = visible(selector);
      if (!node) return null;
      const symbol = cleanText(
        node.querySelector(".andes-money-amount__currency-symbol")?.textContent,
        10
      );
      if (symbol !== "R$" && node.getAttribute("data-currency-id") !== "BRL" && currency !== "BRL" && !node.closest(".ui-pdp-price")?.textContent?.includes("R$"))
        return null;
      const fraction = cleanText(
        node.querySelector(".andes-money-amount__fraction")?.textContent,
        30
      ).replace(/\./g, "");
      const cents = cleanText(
        node.querySelector(".andes-money-amount__cents")?.textContent,
        3
      );
      if (!fraction || cents && !/^\d{1,2}$/.test(cents)) return null;
      return parseMoney(fraction + (cents ? "," + cents.padStart(2, "0") : ""));
    };
    const currentPrice = amount2(".ui-pdp-price__second-line .andes-money-amount:not(s)") ?? (currency === "BRL" ? parseMoney(offer.price ?? meta("product:price:amount")) : null);
    const specs = Array.isArray(offer.priceSpecification) ? offer.priceSpecification : [offer.priceSpecification];
    const old = specs.find(
      (spec) => isRecord(spec) && typeof spec.priceType === "string" && /(?:^|[/#])StrikethroughPrice$/.test(spec.priceType) && spec.priceCurrency === "BRL"
    );
    const oldPrice = amount2(".ui-pdp-price__original-value") ?? amount2(
      ".ui-pdp-price s.andes-money-amount, .ui-pdp-price s .andes-money-amount, .ui-pdp-price .andes-money-amount--previous"
    ) ?? parseMoney(old?.price);
    return {
      currentPrice,
      originalPrice: oldPrice !== null && currentPrice !== null && oldPrice > currentPrice ? oldPrice : null
    };
  }

  // src/collector/mercado-livre/images.ts
  function readImages(product) {
    const images = /* @__PURE__ */ new Set();
    const add2 = (value) => {
      if (images.size >= LIMITS.images || typeof value !== "string") return;
      try {
        const url = new URL(value, location.href);
        if (url.protocol === "https:" && (url.hostname === "mlstatic.com" || url.hostname.endsWith(".mlstatic.com")) && !url.username && !url.password && url.href.length <= LIMITS.url)
          images.add(largerImage(url));
      } catch {
      }
    };
    for (const image of document.querySelectorAll(
      ".ui-pdp-gallery__figure img, img.ui-pdp-image"
    ))
      add2(
        image.getAttribute("data-zoom") || image.getAttribute("data-src") || image.currentSrc || image.src
      );
    const values = Array.isArray(product?.image) ? product.image : [product?.image];
    for (const value of values)
      add2(isRecord(value) ? value.contentUrl || value.url : value);
    add2(meta("og:image"));
    return [...images];
  }

  // src/collector/mercado-livre/index.ts
  function captureProduct() {
    if (!isMercadoLivreHost(location.hostname))
      throw new Error(
        "Abra o an\xFAncio direto do produto no Mercado Livre antes de capturar."
      );
    const product = structuredProduct();
    const heading = visible('h1.ui-pdp-title, h1[itemprop="name"]');
    const productPath = /(?:^\/MLB-?\d+(?:-|_|\/|$)|\/p\/MLB\d+(?:\/|$))/i.test(
      location.pathname
    );
    if (!heading && !(productPath && product))
      throw new Error(
        "Esta p\xE1gina n\xE3o parece ser um an\xFAncio. Abra o produto, aguarde carregar e tente novamente."
      );
    const prices = readPrices(product);
    const imageUrls = readImages(product);
    const attributes = [...document.querySelectorAll(".ui-pdp-specs__table tr")].slice(0, 12).flatMap((row) => {
      const label = cleanText(row.querySelector("th")?.textContent, 100), value = cleanText(row.querySelector("td")?.textContent, 200);
      return label && value ? [label + ": " + value] : [];
    });
    const title = cleanText(
      heading?.textContent || product?.name || meta("og:title"),
      LIMITS.title
    ).replace(/\s*\|\s*Mercado\s*Livre.*$/i, "");
    const description = cleanText(
      document.querySelector(".ui-pdp-description__content")?.textContent || product?.description,
      LIMITS.description
    ) || attributes.join("\n").slice(0, LIMITS.description) || cleanText(meta("og:description"), LIMITS.description);
    const sourceUrl = new URL(location.href);
    sourceUrl.hash = "";
    if (sourceUrl.href.length > LIMITS.url)
      throw new Error(
        "O link do an\xFAncio \xE9 muito longo. Abra o link direto do produto."
      );
    const warnings = [];
    if (!title) warnings.push("T\xEDtulo n\xE3o encontrado.");
    if (!description)
      warnings.push(
        "Descri\xE7\xE3o n\xE3o encontrada. Abra a descri\xE7\xE3o do an\xFAncio e capture novamente, ou complete no PromoFlow."
      );
    if (!imageUrls.length) warnings.push("Imagem n\xE3o encontrada.");
    if (prices.originalPrice === null)
      warnings.push(
        "Pre\xE7o antigo n\xE3o encontrado ou sem desconto confirmado. A oferta ficar\xE1 somente com o pre\xE7o atual."
      );
    if (prices.currentPrice === null)
      warnings.push("Pre\xE7o n\xE3o encontrado. Informe o valor final manualmente.");
    warnings.push(
      "Confira a varia\xE7\xE3o, pre\xE7o \xE0 vista, frete e condi\xE7\xF5es de cupom antes de salvar."
    );
    return {
      version: 1,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      draft: {
        sourceUrl: sourceUrl.href,
        title,
        description,
        imageUrls,
        ...prices
      },
      warnings
    };
  }

  // src/collector/amazon/prices.ts
  function readAmazonPrices(product) {
    const read = (selectors) => {
      for (const selector of selectors) {
        const node = visible(selector);
        if (!node) continue;
        const whole = node.querySelector(".a-price-whole");
        const cents = node.querySelector(".a-price-fraction");
        const offscreen = node.querySelector(".a-offscreen");
        if (!offscreen && whole && cents && node.textContent?.includes("R$")) {
          const fraction = cleanText(whole.textContent, 30).replace(
            /[^0-9]/g,
            ""
          );
          const decimal = cleanText(cents.textContent, 3);
          if (/^\d{1,2}$/.test(decimal)) {
            const amount2 = parseMoney(fraction + "," + decimal.padStart(2, "0"));
            if (amount2 !== null) return amount2;
          }
        }
        const raw = cleanText(
          offscreen?.textContent || (!whole ? node.textContent : ""),
          100
        );
        const match = raw.match(/R\$\s*([\d.]+(?:,\d{1,2})?)/);
        if (match) {
          const amount2 = parseMoney(match[1]);
          if (amount2 !== null) return amount2;
        }
      }
      return null;
    };
    const first = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
    const offer = isRecord(first) ? first : {};
    const currentPrice = read([
      "#corePriceDisplay_desktop_feature_div .priceToPay",
      "#corePrice_feature_div .priceToPay",
      "#apex_desktop .apexPriceToPay",
      "#corePriceDisplay_desktop_feature_div .a-price:not(.a-text-price)",
      "#corePrice_feature_div .a-price:not(.a-text-price)",
      "#priceblock_dealprice",
      "#priceblock_ourprice",
      "#priceblock_saleprice",
      "#price_inside_buybox",
      "#newBuyBoxPrice"
    ]) ?? (offer.priceCurrency === "BRL" ? parseMoney(offer.price) : null);
    const original = read([
      "#corePriceDisplay_desktop_feature_div .basisPrice .a-text-price",
      '#corePriceDisplay_desktop_feature_div .a-text-price[data-a-strike="true"]',
      "#corePriceDisplay_desktop_feature_div .basisPrice",
      "#corePrice_feature_div .basisPrice .a-text-price",
      '#corePrice_feature_div .a-text-price[data-a-strike="true"]',
      "#price .a-text-price"
    ]);
    return {
      currentPrice,
      originalPrice: original !== null && currentPrice !== null && original > currentPrice ? original : null
    };
  }

  // src/collector/amazon/images.ts
  function readAmazonImages(product) {
    const images = /* @__PURE__ */ new Set();
    const identities = /* @__PURE__ */ new Set();
    const add2 = (value, thumbnail = false) => {
      if (typeof value !== "string" || images.size >= LIMITS.images) return;
      try {
        const url = new URL(value, location.href);
        if (url.protocol !== "https:" || !isProductImageHost(url.hostname) || url.username || url.password || url.href.length > LIMITS.url)
          return;
        if (thumbnail)
          url.pathname = url.pathname.replace(
            /\._[^/]+_\.(jpe?g|png|webp)$/i,
            ".$1"
          );
        const identity = url.hostname + url.pathname.replace(/\._[^/]+_\.(jpe?g|png|webp)$/i, ".$1");
        if (identities.has(identity)) return;
        identities.add(identity);
        images.add(url.href);
      } catch {
      }
    };
    for (const image of document.querySelectorAll(
      "#landingImage, #imgBlkFront, #ebooksImgBlkFront, #imageBlock img.a-dynamic-image"
    )) {
      add2(image.getAttribute("data-old-hires"));
      const raw = image.getAttribute("data-a-dynamic-image");
      if (raw && raw.length <= 5e4) {
        try {
          const dynamic = JSON.parse(raw);
          if (isRecord(dynamic)) {
            const entries = Object.entries(dynamic).map(([url, dimensions]) => {
              const size = Array.isArray(dimensions) && typeof dimensions[0] === "number" && typeof dimensions[1] === "number" ? dimensions[0] * dimensions[1] : 0;
              return { url, size };
            }).sort((a, b) => b.size - a.size);
            if (entries[0]) add2(entries[0].url);
          }
        } catch {
        }
      }
      if (!images.size) add2(image.currentSrc || image.src, true);
    }
    const values = Array.isArray(product?.image) ? product.image : [product?.image];
    for (const image of values)
      add2(isRecord(image) ? image.contentUrl || image.url : image);
    for (const image of document.querySelectorAll(
      "#altImages li.imageThumbnail img"
    ))
      add2(image.getAttribute("data-src") || image.currentSrc || image.src, true);
    add2(meta("og:image"));
    return [...images];
  }

  // src/collector/amazon/index.ts
  function captureAmazonProduct() {
    if (!isAmazonHost(location.hostname))
      throw new Error("Abra o produto na Amazon Brasil.");
    const heading = visible("#productTitle, #title #title");
    const input = document.querySelector(
      '#ASIN, input[name="ASIN"]'
    );
    const pathAsin = location.pathname.match(
      /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:\/|$)/i
    )?.[1];
    const asin = /^[A-Z0-9]{10}$/i.test(input?.value || "") ? input?.value : pathAsin;
    if (!heading || !asin)
      throw new Error(
        "Esta p\xE1gina n\xE3o parece ser um produto da Amazon. Abra o an\xFAncio, escolha a varia\xE7\xE3o e aguarde carregar."
      );
    const product = structuredProduct();
    const title = cleanText(heading.textContent || product?.name, LIMITS.title);
    const bullets = [
      ...document.querySelectorAll("#feature-bullets li .a-list-item")
    ].map((node) => cleanText(node.textContent, 600)).filter((value) => value && !/^ver mais|^veja mais/i.test(value));
    const description = (bullets.length ? bullets.join("\n") : cleanText(
      document.querySelector("#productDescription")?.textContent || product?.description,
      LIMITS.description
    )).slice(0, LIMITS.description);
    const prices = readAmazonPrices(product), imageUrls = readAmazonImages(product);
    const originalUrl = new URL(location.href);
    originalUrl.hash = "";
    let sourceUrl = originalUrl;
    if (asin !== pathAsin || originalUrl.href.length > LIMITS.url) {
      sourceUrl = new URL("/dp/" + asin, location.origin);
      for (const key of ["smid", "tag", "linkCode", "th", "psc"]) {
        const value = originalUrl.searchParams.get(key);
        if (value && value.length < 200) sourceUrl.searchParams.set(key, value);
      }
    }
    const warnings = [];
    if (!description)
      warnings.push("Descri\xE7\xE3o n\xE3o encontrada. Complete no PromoFlow.");
    if (!imageUrls.length) warnings.push("Imagem n\xE3o encontrada.");
    if (prices.currentPrice === null)
      warnings.push("Pre\xE7o em reais n\xE3o encontrado. Informe manualmente.");
    if (prices.originalPrice === null)
      warnings.push("Pre\xE7o antigo n\xE3o encontrado ou sem desconto confirmado.");
    warnings.push(
      "Confira varia\xE7\xE3o, vendedor, CEP, Prime, Pix e cupom na Amazon. O pre\xE7o capturado n\xE3o inclui descontos condicionais n\xE3o aplicados."
    );
    return {
      version: 1,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      draft: {
        sourceUrl: sourceUrl.href,
        title,
        description,
        imageUrls,
        ...prices
      },
      warnings
    };
  }

  // src/collector/index.ts
  function capture() {
    if (isShopeeHost(location.hostname)) return captureShopeeProduct();
    if (isAmazonHost(location.hostname)) return captureAmazonProduct();
    if (isMercadoLivreHost(location.hostname)) return captureProduct();
    throw new Error(
      "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee."
    );
  }
  var captured = capture();
  var stripe = isAmazonHost(location.hostname) ? readAmazonSiteStripe(document) : {};
  captured.draft.sourceCategory = stripe.category ?? readSourceCategory(captured.draft.title);
  if (stripe.commissionRate !== void 0) captured.draft.affiliateCommissionRate = stripe.commissionRate;
  var result = captured;
  return __toCommonJS(index_exports);
})();
PromoFlowCapture.result;
