"use strict";
(() => {
  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  var APP_ORIGINS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function appOrigin(value) {
    try {
      const url = new URL(value || "");
      return APP_ORIGINS.some((origin) => origin === url.origin) ? url.origin : null;
    } catch {
      return null;
    }
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }

  // src/affiliate/app-bridge.ts
  if (appOrigin(location.href)) {
    const ready = () => {
      for (const feature of ["mercado-affiliate-v1", "mercado-affiliate-v2"])
        window.postMessage(
          {
            type: "PROMOFLOW_EXTENSION_READY",
            feature,
            version: chrome.runtime.getManifest().version
          },
          location.origin
        );
    };
    ready();
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin || !isRecord(event.data))
        return;
      const data = event.data;
      if (data.type === "PROMOFLOW_EXTENSION_HELLO") ready();
      if (data.type !== "PROMOFLOW_AFFILIATE_BEGIN" || !validRequestId(data.requestId) || !validRequestId(data.accountId) || !mercadoLink(data.productUrl))
        return;
      void chrome.runtime.sendMessage({ ...data, type: "AFFILIATE_BEGIN" }).then((result) => {
        const ok = isRecord(result) && result.ok === true;
        window.postMessage(
          {
            type: "PROMOFLOW_AFFILIATE_OPENED",
            requestId: data.requestId,
            ok,
            error: isRecord(result) && typeof result.error === "string" ? result.error : "N\xE3o foi poss\xEDvel abrir o produto."
          },
          location.origin
        );
      }).catch(
        () => window.postMessage(
          {
            type: "PROMOFLOW_AFFILIATE_OPENED",
            requestId: data.requestId,
            ok: false,
            error: "Recarregue a extens\xE3o e esta p\xE1gina."
          },
          location.origin
        )
      );
    });
    chrome.runtime.onMessage.addListener((message, sender) => {
      if (sender.id === chrome.runtime.id && isRecord(message) && message.type === "AFFILIATE_RESULT" && validRequestId(message.requestId) && validRequestId(message.accountId) && mercadoLink(message.affiliateUrl))
        window.postMessage(
          { ...message, type: "PROMOFLOW_AFFILIATE_RESULT" },
          location.origin
        );
      if (sender.id === chrome.runtime.id && isRecord(message) && message.type === "AFFILIATE_PROGRESS" && validRequestId(message.requestId) && validRequestId(message.accountId))
        window.postMessage(
          { ...message, type: "PROMOFLOW_AFFILIATE_PROGRESS" },
          location.origin
        );
      return false;
    });
  }
})();
