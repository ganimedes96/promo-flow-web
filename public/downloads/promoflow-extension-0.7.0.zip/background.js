"use strict";
(() => {
  // src/affiliate/watch-copy.ts
  function watchAffiliateCopy(requestId, expiresAt) {
    const valid = (value) => {
      if (value.length > 2048) return false;
      try {
        const url = new URL(value);
        return url.protocol === "https:" && !url.username && !url.password && !url.port && (url.hostname === "meli.la" || url.hostname === "www.meli.la" || url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br"));
      } catch {
        return false;
      }
    };
    const notify = (value) => {
      const link = value.trim();
      if (Date.now() < expiresAt && valid(link)) window.postMessage({ type: "PROMOFLOW_ML_LINK_COPIED", requestId, link }, location.origin);
    };
    const clipboard = navigator.clipboard;
    const original = clipboard?.writeText;
    const wrapped = original ? async (value) => {
      await original.call(clipboard, value);
      notify(value);
    } : void 0;
    try {
      if (wrapped) Object.defineProperty(clipboard, "writeText", { configurable: true, value: wrapped });
    } catch {
    }
    const copy = (event) => {
      const value = event.clipboardData?.getData("text/plain");
      if (value) notify(value);
    };
    const finish = () => {
      document.removeEventListener("copy", copy);
      window.removeEventListener("message", stop);
      if (wrapped && clipboard.writeText === wrapped) {
        try {
          Object.defineProperty(clipboard, "writeText", { configurable: true, value: original });
        } catch {
        }
      }
    };
    const stop = (event) => {
      if (event.source === window && event.origin === location.origin && event.data?.type === "PROMOFLOW_ML_STOP_COPY" && event.data?.requestId === requestId) finish();
    };
    document.addEventListener("copy", copy);
    window.addEventListener("message", stop);
    setTimeout(finish, Math.max(0, expiresAt - Date.now()));
  }

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/services/account.ts
  var apiFor = (destination) => {
    if (!DESTINATIONS.includes(destination))
      throw new Error("Ambiente inv\xE1lido.");
    return destination + "/api/extension-auth";
  };
  async function requestAccount(destination, action, options = {}) {
    const response = await fetch(apiFor(destination) + "/" + action, {
      ...options,
      credentials: "omit",
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(2e4)
    }).catch(() => {
      throw new Error(
        destination === "http://localhost:3000" ? "N\xE3o foi poss\xEDvel acessar o PromoFlow local. Inicie o frontend em localhost:3000 e recarregue a extens\xE3o." : "N\xE3o foi poss\xEDvel acessar o PromoFlow. Verifique sua conex\xE3o e tente novamente."
      );
    });
    if (!response.ok && response.status !== 401) {
      const payload = await response.json().catch(() => null);
      const message = typeof payload === "object" && payload !== null && "message" in payload && typeof payload.message === "string" ? payload.message : "";
      throw new Error(
        response.status === 404 ? "O frontend ainda n\xE3o tem a conex\xE3o atualizada da extens\xE3o. Atualize ou reinicie o PromoFlow e tente novamente." : message || "N\xE3o foi poss\xEDvel consultar o PromoFlow. Tente novamente."
      );
    }
    return response;
  }
  var key = (destination) => "connection:" + destination;
  async function getAccount(destination) {
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    if (!stored) return null;
    if (new Date(stored.expiresAt).getTime() <= Date.now()) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    const response = await requestAccount(destination, "me", {
      headers: { Authorization: "Bearer " + stored.token },
      cache: "no-store"
    });
    if (response.status === 401) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    if (!response.ok)
      throw new Error("N\xE3o foi poss\xEDvel consultar sua conex\xE3o. Tente novamente.");
    const payload = await response.json();
    return payload.data.user;
  }
  var random = () => Array.from(
    crypto.getRandomValues(new Uint8Array(32)),
    (v) => v.toString(16).padStart(2, "0")
  ).join("");
  async function connectAccount(destination) {
    apiFor(destination);
    const verifier = random(), state = random();
    const digest = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(verifier)
    );
    const challenge = btoa(String.fromCharCode(...new Uint8Array(digest))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const redirectUri = chrome.identity.getRedirectURL("promoflow");
    const url = new URL(destination + "/extension/connect");
    url.searchParams.set("challenge", challenge);
    url.searchParams.set("state", state);
    url.searchParams.set("redirectUri", redirectUri);
    const callback = await chrome.identity.launchWebAuthFlow({
      url: url.toString(),
      interactive: true
    });
    if (!callback) throw new Error("Conex\xE3o cancelada.");
    const returned = new URL(callback);
    if (returned.origin !== new URL(redirectUri).origin || returned.pathname !== "/promoflow")
      throw new Error("Retorno da conex\xE3o inv\xE1lido.");
    const params = new URLSearchParams(returned.hash.slice(1));
    if (params.get("state") !== state) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    if (params.get("error") === "access_denied")
      throw new Error("Conex\xE3o cancelada.");
    if (!params.get("code")) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    const response = await requestAccount(destination, "exchange", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: params.get("code"),
        challenge,
        verifier,
        redirectUri
      })
    });
    if (!response.ok)
      throw new Error("A autoriza\xE7\xE3o expirou. Conecte novamente.");
    const result = await response.json();
    if (!/^[a-f0-9]{64}$/.test(result.data.token))
      throw new Error("Resposta de conex\xE3o inv\xE1lida.");
    await chrome.storage.local.set({ [key(destination)]: result.data });
  }
  async function getPreferences() {
    const saved = (await chrome.storage.local.get("importPreferences")).importPreferences;
    return {
      destination: saved?.destination && DESTINATIONS.includes(saved.destination) ? saved.destination : DESTINATIONS[0],
      target: saved?.target === "central" ? "central" : "offer"
    };
  }

  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  var APP_ORIGINS = ["https://promo-flow-web-zeta.vercel.app", "http://localhost:3000"];
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function appOrigin(value) {
    try {
      const url = new URL(value || "");
      return APP_ORIGINS.some((origin) => origin === url.origin) ? url.origin : null;
    } catch {
      return null;
    }
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }
  function pendingAffiliate(value, now = Date.now()) {
    if (!isRecord(value) || !validRequestId(value.requestId) || !validRequestId(value.accountId) || typeof value.origin !== "string" || appOrigin(value.origin) !== value.origin || typeof value.sourceTabId !== "number" || !Number.isInteger(value.sourceTabId) || typeof value.productTabId !== "number" || !Number.isInteger(value.productTabId) || !mercadoLink(value.sourceUrl) || typeof value.expiresAt !== "number" || value.expiresAt <= now || value.expiresAt > now + AFFILIATE_TTL + 1e3) return null;
    return { requestId: value.requestId, accountId: value.accountId, origin: value.origin, sourceTabId: value.sourceTabId, productTabId: value.productTabId, sourceUrl: value.sourceUrl, expiresAt: value.expiresAt };
  }

  // src/affiliate/background.ts
  var key2 = (tabId) => `affiliate:${tabId}`;
  async function read(tabId) {
    const value = (await chrome.storage.session.get(key2(tabId)))[key2(tabId)];
    return pendingAffiliate(value);
  }
  async function handle(message, sender) {
    const tabId = sender.tab?.id;
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || tabId === void 0) throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
    if (message.type === "AFFILIATE_BEGIN") {
      const origin = appOrigin(sender.url);
      if (!origin || !validRequestId(message.requestId) || !validRequestId(message.accountId) || !mercadoLink(message.productUrl)) throw new Error("Produto ou ambiente inv\xE1lido.");
      const account = await getAccount(origin);
      if (!account || account.id !== message.accountId) throw new Error("Conecte a extens\xE3o \xE0 mesma conta e ambiente do formul\xE1rio.");
      const stored = await chrome.storage.session.get(null);
      const stale = Object.entries(stored).filter(([name, value]) => name.startsWith("affiliate:") && (!pendingAffiliate(value) || isRecord(value) && value.sourceTabId === tabId)).map(([name]) => name);
      if (stale.length) await chrome.storage.session.remove(stale);
      const tab = await chrome.tabs.create({ url: message.productUrl, active: true });
      if (tab.id === void 0) throw new Error("N\xE3o foi poss\xEDvel abrir o produto.");
      await chrome.storage.session.set({ [key2(tab.id)]: { requestId: message.requestId, accountId: account.id, origin, sourceTabId: tabId, productTabId: tab.id, sourceUrl: message.productUrl, expiresAt: Date.now() + AFFILIATE_TTL } });
      return { ok: true };
    }
    const pending = await read(tabId);
    if (!pending || !sender.url || !mercadoLink(sender.url)) throw new Error("Solicita\xE7\xE3o expirada. Volte ao formul\xE1rio e tente novamente.");
    if (message.type === "AFFILIATE_WATCH_COPY") {
      await chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: watchAffiliateCopy, args: [pending.requestId, pending.expiresAt] });
      return { ok: true };
    }
    if (message.type === "AFFILIATE_CONTEXT") return { ok: true, requestId: pending.requestId };
    if (message.type === "AFFILIATE_COMPLETE" && message.requestId === pending.requestId && mercadoLink(message.affiliateUrl)) {
      if (message.affiliateUrl === pending.sourceUrl) throw new Error("Esse \xE9 o link original. Gere seu pr\xF3prio link na Barra de Afiliados.");
      const source = await chrome.tabs.get(pending.sourceTabId);
      const account = await getAccount(pending.origin);
      if (appOrigin(source.url) !== pending.origin || !account || account.id !== pending.accountId) throw new Error("Sua conta ou formul\xE1rio mudou. Inicie novamente no PromoFlow.");
      await chrome.tabs.sendMessage(pending.sourceTabId, { type: "AFFILIATE_RESULT", requestId: pending.requestId, accountId: pending.accountId, affiliateUrl: message.affiliateUrl });
      await chrome.storage.session.remove(key2(tabId));
      await chrome.tabs.update(pending.sourceTabId, { active: true });
      return { ok: true };
    }
    throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (!isRecord(message) || !["AFFILIATE_BEGIN", "AFFILIATE_CONTEXT", "AFFILIATE_COMPLETE", "AFFILIATE_WATCH_COPY"].includes(String(message.type))) return false;
    void handle(message, sender).then(respond).catch((error) => respond({ ok: false, error: error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel preparar o link." }));
    return true;
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void chrome.storage.session.get(null).then(async (values) => {
      const keys = Object.entries(values).filter(([name, value]) => name.startsWith("affiliate:") && (!pendingAffiliate(value) || isRecord(value) && (value.sourceTabId === tabId || value.productTabId === tabId))).map(([name]) => name);
      if (keys.length) await chrome.storage.session.remove(keys);
    });
  });

  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host) || isShopeeHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || [
        "meli.la",
        "www.meli.la",
        "amzn.to",
        "a.co",
        "shope.ee",
        "shp.ee"
      ].some(
        (domain) => url.hostname === domain || url.hostname.endsWith("." + domain)
      ));
    } catch {
      return false;
    }
  }

  // src/shared/value.ts
  function isRecord2(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord2(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord2(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return (draft.sourceCategory === void 0 || typeof draft.sourceCategory === "string" && draft.sourceCategory.length <= 300) && typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre, na Amazon Brasil ou na Shopee."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector.js"]
    });
    const data = injection?.result;
    if (!isCapturedProduct(data))
      throw new Error(
        "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
      );
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const account = await getAccount(options.destination);
    if (!account)
      throw new Error("Conecte sua conta pelo bot\xE3o Conectar ao PromoFlow.");
    if (options.target === "central" && account.role !== "admin")
      throw new Error("A central \xE9 exclusiva do administrador.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil, Shopee ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured,
      accountId: account.id,
      target: options.target || "offer",
      draft: { ...captured.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/background/index.ts
  var capturing = false;
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "capture-product" || capturing) return;
    capturing = true;
    void (async () => {
      try {
        await chrome.action.setBadgeText({ text: "..." });
        const product = await captureActiveProduct(tab);
        await openDraft(product, {
          ...await getPreferences(),
          affiliateUrl: "",
          couponCode: ""
        });
        await chrome.action.setBadgeText({ text: "" });
        await chrome.action.setTitle({
          title: "Importar produto para o PromoFlow"
        });
      } catch (error) {
        await chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
        await chrome.action.setBadgeText({ text: "!" });
        await chrome.action.setTitle({
          title: "Falha ao importar: " + errorMessage(error, "Abra um produto e tente novamente.").slice(
            0,
            220
          )
        });
      } finally {
        capturing = false;
      }
    })().catch((error) => {
      capturing = false;
      console.error(errorMessage(error, "Falha ao importar produto."));
    });
  });
  void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  var connecting = false;
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html"))
      return false;
    if (typeof message !== "object" || message === null || !("type" in message) || message.type !== "CONNECT_ACCOUNT" || !("destination" in message) || typeof message.destination !== "string")
      return false;
    if (connecting) {
      respond({ ok: false, error: "J\xE1 existe uma conex\xE3o em andamento." });
      return false;
    }
    connecting = true;
    void connectAccount(message.destination).then(() => respond({ ok: true })).catch(
      (error) => respond({
        ok: false,
        error: errorMessage(error, "N\xE3o foi poss\xEDvel conectar.")
      })
    ).finally(() => {
      connecting = false;
    });
    return true;
  });
})();
