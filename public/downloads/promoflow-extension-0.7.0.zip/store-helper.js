"use strict";
(() => {
  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }

  // src/affiliate/store-helper.ts
  async function start() {
    let context;
    for (let attempt = 0; attempt < 3; attempt++) {
      context = await chrome.runtime.sendMessage({ type: "AFFILIATE_CONTEXT" }).catch(() => null);
      if (isRecord(context) && context.ok === true) break;
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    if (!isRecord(context) || context.ok !== true || !validRequestId(context.requestId)) return;
    const requestId = context.requestId;
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;right:20px;bottom:20px;width:min(360px,calc(100vw - 40px));z-index:2147483647;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = ":host{font:14px system-ui;color:#f4f7ee}section{background:#15251c;border:1px solid #90b269;border-radius:18px;padding:20px;box-shadow:0 12px 40px #0005}h2{margin:0 0 10px;font-size:18px}p{line-height:1.5;font-size:13px;color:#d5e1cd}label{display:block;font-size:12px;margin:15px 0 6px}input{box-sizing:border-box;width:100%;padding:10px;border-radius:8px;border:1px solid #94a98a;background:#fff;color:#15251c}button{margin-top:12px;border:0;border-radius:9px;padding:11px 14px;background:#d7fa72;color:#15251c;font-weight:700;cursor:pointer}button:disabled{opacity:.5;cursor:wait}.close{float:right;margin:-4px -4px 0 0;padding:3px 8px;background:transparent;color:white}";
    root.append(style);
    const section = document.createElement("section");
    const close = document.createElement("button");
    close.textContent = "\xD7";
    close.className = "close";
    close.setAttribute("aria-label", "Fechar assistente");
    close.onclick = () => {
      window.postMessage({ type: "PROMOFLOW_ML_STOP_COPY", requestId }, location.origin);
      host.remove();
    };
    const title = document.createElement("h2");
    title.textContent = "Seu link no PromoFlow";
    const description = document.createElement("p");
    description.textContent = "Na Barra de Afiliados do Mercado Livre, gere e copie seu link. Ele aparece abaixo para voc\xEA confirmar. Se n\xE3o aparecer, cole o link gerado na sua conta.";
    const label = document.createElement("label");
    label.textContent = "Link gerado na sua conta";
    label.htmlFor = "link";
    const input = document.createElement("input");
    input.id = "link";
    input.type = "url";
    input.maxLength = 2048;
    input.placeholder = "https://meli.la/...";
    const status = document.createElement("p");
    status.setAttribute("role", "status");
    const button = document.createElement("button");
    button.textContent = "Usar este link e voltar";
    button.onclick = () => {
      const link = input.value.trim();
      if (!mercadoLink(link)) {
        status.textContent = "Informe um link HTTPS do Mercado Livre ou meli.la.";
        return;
      }
      button.disabled = true;
      void chrome.runtime.sendMessage({ type: "AFFILIATE_COMPLETE", requestId, affiliateUrl: link }).then((result) => {
        if (!isRecord(result) || result.ok !== true) {
          status.textContent = isRecord(result) && typeof result.error === "string" ? result.error : "N\xE3o foi poss\xEDvel retornar ao formul\xE1rio.";
          button.disabled = false;
          return;
        }
        window.postMessage({ type: "PROMOFLOW_ML_STOP_COPY", requestId }, location.origin);
        status.textContent = "Link enviado ao formul\xE1rio. Confira antes de salvar.";
      }).catch(() => {
        status.textContent = "Recarregue a extens\xE3o e inicie pelo PromoFlow novamente.";
        button.disabled = false;
      });
    };
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin || !isRecord(event.data) || event.data.type !== "PROMOFLOW_ML_LINK_COPIED" || event.data.requestId !== requestId || !mercadoLink(event.data.link)) return;
      input.value = event.data.link;
      status.textContent = "Link copiado na loja. Confirme que foi gerado pela sua conta e clique em usar.";
    });
    void chrome.runtime.sendMessage({ type: "AFFILIATE_WATCH_COPY" }).catch(() => void 0);
    section.append(close, title, description, label, input, button, status);
    root.append(section);
    document.documentElement.append(host);
  }
  void start();
})();
