"use strict";
(() => {
  // src/affiliate/shopee/links.ts
  function shopeeLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const u = new URL(value);
      return u.protocol === "https:" && !u.username && !u.password && !u.port && ["shopee.com.br", "www.shopee.com.br", "s.shopee.com.br", "shope.ee", "shp.ee", "affiliate.shopee.com.br"].includes(u.hostname);
    } catch {
      return false;
    }
  }
  function shopeeGenerator(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return u.hostname === "affiliate.shopee.com.br" && u.pathname.replace(/\/$/, "") === "/offer/custom_link";
  }
  function shopeeProduct(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return ["shopee.com.br", "www.shopee.com.br"].includes(u.hostname) && /(?:-i\.\d+\.\d+|\/product\/\d+\/\d+)\/?$/.test(u.pathname);
  }
  function cleanShopeeProduct(value) {
    if (!shopeeProduct(value)) return null;
    const u = new URL(value);
    const ids = u.pathname.match(/-i\.(\d+)\.(\d+)/) || u.pathname.match(/\/product\/(\d+)\/(\d+)/);
    if (!ids) return null;
    const out = new URL("https://shopee.com.br/product/" + ids[1] + "/" + ids[2]);
    for (const key of ["extraParams", "model_id", "variation_id"]) {
      const value2 = u.searchParams.get(key);
      if (value2) out.searchParams.set(key, value2);
    }
    return out.href;
  }
  function shopeeGenerated(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return ["s.shopee.com.br", "shope.ee", "shp.ee"].includes(u.hostname) && /^\/[a-z0-9_-]+\/?$/i.test(u.pathname) || shopeeProduct(value) && !!u.searchParams.get("af_siteid");
  }

  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }
  function mercadoGeneratorUrl(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return url.hostname === "www.mercadolivre.com.br" && url.pathname.replace(/\/$/, "") === "/afiliados/linkbuilder";
  }

  // src/affiliate/mercado-livre/dom.ts
  function isVisible(element) {
    if (element.closest('[hidden],[aria-hidden="true"]')) return false;
    for (let current = element; current; current = current.parentElement) {
      const view = current.ownerDocument.defaultView;
      const style = typeof view?.getComputedStyle === "function" ? view.getComputedStyle(current) : current instanceof HTMLElement ? current.style : null;
      if (style && (style.display === "none" || style.visibility === "hidden"))
        return false;
    }
    return true;
  }

  // src/affiliate/mercado-livre/links.ts
  function isLinkBuilder(value) {
    return mercadoGeneratorUrl(value);
  }
  function isProductLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br")) && /\bMLBU?-?\d{6,}/i.test(url.pathname);
  }
  function generatedLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "meli.la" || url.hostname === "www.meli.la") && /^\/[a-z0-9]+\/?$/i.test(url.pathname) || (url.searchParams.has("matt_tool") || url.searchParams.has("ref")) && (url.pathname.startsWith("/social/") || isProductLink(value));
  }

  // src/affiliate/mercado-livre/generator.ts
  var GeneratorError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
    code;
  };
  function normalize(text) {
    return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function name(element, doc) {
    const labelledBy = element.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => doc.getElementById(id)?.textContent || "").join(" ");
    const label = element.id ? Array.from(doc.querySelectorAll("label")).find(
      (label2) => label2.getAttribute("for") === element.id
    )?.textContent : "";
    return normalize(
      [
        element.getAttribute("aria-label"),
        element.getAttribute("placeholder"),
        labelledBy,
        label
      ].filter(Boolean).join(" ")
    );
  }
  function locateGenerator(doc) {
    const inputs = Array.from(
      doc.querySelectorAll(
        "input,textarea"
      )
    ).filter(
      (element) => isVisible(element) && !element.disabled && !element.readOnly && (element instanceof HTMLTextAreaElement || ["url", "text", "search"].includes(element.type || "text")) && /(?:url|link|endereco).*(?:produto|insira|cole|shopee)|(?:insira|cole).*(?:url|link)|^url$/.test(
        name(element, doc)
      )
    );
    if (inputs.length > 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "H\xE1 mais de um campo de produto. Preencha pelo gerador e use o retorno manual."
      );
    const input = inputs[0];
    if (!input) return null;
    const scope = input.closest("form") || doc.querySelector("main") || doc.body;
    const buttons = Array.from(
      scope.querySelectorAll(
        'button,input[type="submit"]'
      )
    ).filter(
      (button) => isVisible(button) && /^(?:obter link(?:s)?|converter link(?:s)?|gerar|gerar (?:o |meu |seu )?(?:link|links|produto recomendado|produtos recomendados)(?: de afiliado)?)$/.test(
        normalize(
          button.getAttribute("aria-label") || (button instanceof HTMLInputElement ? button.value : button.textContent) || ""
        )
      )
    );
    if (buttons.length > 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "N\xE3o foi poss\xEDvel identificar com seguran\xE7a o bot\xE3o de gerar link."
      );
    return buttons[0] ? { input, button: buttons[0], scope } : null;
  }
  function generatedOutputs(scope, input, shopee = false) {
    const outputs = [];
    const add = (element, value) => {
      const links = value.match(/https:\/\/[^\s<>"']+/g) || [];
      for (const candidate of links) {
        const link = candidate.replace(/[),.;]+$/, "");
        if ((shopee ? shopeeGenerated(link) : generatedLink(link)) && !outputs.some(
          (output) => output.element === element && output.link === link
        ))
          outputs.push({ element, link });
      }
    };
    for (const element of Array.from(
      scope.querySelectorAll(
        'input[readonly],textarea[readonly],[role="textbox"][aria-readonly="true"]'
      )
    )) {
      if (element !== input && isVisible(element))
        add(
          element,
          "value" in element ? String(element.value) : element.textContent || ""
        );
    }
    for (const button of Array.from(scope.querySelectorAll("button"))) {
      if (!isVisible(button) || !/^copiar(?: (?:o )?link)?$/.test(
        normalize(
          button.getAttribute("aria-label") || button.textContent || ""
        )
      ))
        continue;
      let parent = button.parentElement;
      for (let depth = 0; parent && depth < 3; depth++, parent = parent.parentElement) {
        for (const element of Array.from(
          parent.querySelectorAll("a[href],p,span,code")
        )) {
          if (isVisible(element))
            add(
              element,
              element instanceof HTMLAnchorElement ? element.href : element.textContent || ""
            );
        }
        if (outputs.length) break;
      }
    }
    return outputs;
  }
  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new GeneratorError("CANCELLED", "Convers\xE3o cancelada."));
        return;
      }
      const cancel = () => {
        clearTimeout(timer);
        signal.removeEventListener("abort", cancel);
        reject(new GeneratorError("CANCELLED", "Convers\xE3o cancelada."));
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", cancel);
        resolve();
      }, ms);
      signal.addEventListener("abort", cancel, { once: true });
    });
  }
  async function applyCampaignTag(doc, tag, signal) {
    if (!tag?.trim()) return;
    const expected = normalize(tag);
    const matches = Array.from(
      doc.querySelectorAll('select,[role="combobox"]')
    ).filter(
      (element) => isVisible(element) && /etiqueta|campanha/.test(name(element, doc))
    );
    if (matches.length !== 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "N\xE3o foi poss\xEDvel localizar a etiqueta cadastrada em Lojas. Confira o gerador antes de continuar."
      );
    const control = matches[0];
    if (control.tagName === "SELECT") {
      const select = control;
      const options = Array.from(select.options).filter(
        (option) => !option.disabled && normalize(option.textContent || "") === expected
      );
      if (select.disabled || options.length !== 1)
        throw new GeneratorError(
          "GENERATION_FAILED",
          "A etiqueta cadastrada em Lojas n\xE3o est\xE1 dispon\xEDvel nesta conta do Mercado Livre."
        );
      select.value = options[0].value;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(250, signal);
      if (normalize(select.selectedOptions[0]?.textContent || "") !== expected)
        throw new GeneratorError(
          "GENERATION_FAILED",
          "O gerador n\xE3o confirmou a etiqueta. Confira sua configura\xE7\xE3o em Lojas."
        );
      return;
    }
    if (normalize(control.textContent || "") === expected || normalize(control.getAttribute("value") || "") === expected)
      return;
    control.click();
    for (let attempt = 0; attempt < 12; attempt++) {
      const options = Array.from(
        doc.querySelectorAll('[role="option"]')
      ).filter(
        (option) => isVisible(option) && option.getAttribute("aria-disabled") !== "true" && normalize(option.textContent || "") === expected
      );
      if (options.length === 1) {
        options[0].click();
        await sleep(250, signal);
        if (normalize(control.textContent || "") === expected || normalize(control.getAttribute("value") || "") === expected || options[0].getAttribute("aria-selected") === "true")
          return;
        break;
      }
      if (options.length > 1) break;
      await sleep(150, signal);
    }
    throw new GeneratorError(
      "GENERATION_FAILED",
      "N\xE3o foi poss\xEDvel confirmar a etiqueta cadastrada em Lojas. Nenhum link foi gerado."
    );
  }
  async function generateAffiliateLink(doc, pageUrl, productUrl, signal, onProgress = () => {
  }, timeoutMs = 45e3, campaignTag, shopee = false) {
    if (!(shopee ? shopeeGenerator(pageUrl) && shopeeProduct(productUrl) : isLinkBuilder(pageUrl) && isProductLink(productUrl)))
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "Abra o Gerador de links oficial com um produto v\xE1lido."
      );
    const deadline = Date.now() + timeoutMs;
    let form = null;
    onProgress("Localizando o gerador da sua conta\u2026");
    while (!form && Date.now() < deadline) {
      if (doc.querySelector(
        'input[type="password"],input[autocomplete="one-time-code"]'
      ))
        throw new GeneratorError(
          "LOGIN_REQUIRED",
          "Entre na sua conta do Mercado Livre e tente converter novamente."
        );
      form = locateGenerator(doc);
      if (!form) await sleep(250, signal);
    }
    if (!form)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "O gerador n\xE3o foi encontrado. Confirme seu login e a habilita\xE7\xE3o como afiliado."
      );
    if (signal.aborted)
      throw new GeneratorError("CANCELLED", "Convers\xE3o cancelada.");
    if (shopee && campaignTag?.trim()) {
      const fields = Array.from(doc.querySelectorAll("input")).filter((el) => isVisible(el) && !el.disabled && /sub.?id.?1(?:\b|$)|^sub.?id$/.test(name(el, doc)));
      if (fields.length !== 1) throw new GeneratorError("AMBIGUOUS_FORM", "N\xE3o foi poss\xEDvel identificar o Sub_id 1. Confira a campanha em Lojas.");
      const setter2 = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
      if (!setter2) throw new GeneratorError("FORM_NOT_FOUND", "Campo Sub_id indispon\xEDvel.");
      setter2.call(fields[0], campaignTag);
      fields[0].dispatchEvent(new Event("input", { bubbles: true }));
      fields[0].dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(250, signal);
      if (fields[0].value !== campaignTag) throw new GeneratorError("GENERATION_FAILED", "A Shopee n\xE3o confirmou o Sub_id.");
    } else if (!shopee) await applyCampaignTag(doc, campaignTag, signal);
    const { input, button, scope } = form;
    onProgress("Preenchendo o produto no gerador\u2026");
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "N\xE3o foi poss\xEDvel preencher o campo do gerador."
      );
    setter.call(input, productUrl);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    while (button.disabled && Date.now() < deadline) await sleep(250, signal);
    if (button.disabled)
      throw new GeneratorError(
        "GENERATION_FAILED",
        "O Mercado Livre n\xE3o liberou a gera\xE7\xE3o. Confira a etiqueta selecionada e o produto."
      );
    await sleep(100, signal);
    if (!input.isConnected || !button.isConnected || input.value.trim() !== productUrl)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "O formul\xE1rio mudou durante a prepara\xE7\xE3o. Tente novamente."
      );
    const resultScope = shopee ? doc.body : scope;
    const baseline = generatedOutputs(resultScope, input, shopee);
    const touched = /* @__PURE__ */ new Set();
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        const target = record.target.nodeType === 1 ? record.target : record.target.parentElement;
        if (target) touched.add(target);
        for (const node of Array.from(record.addedNodes))
          if (node.nodeType === 1) touched.add(node);
      }
    });
    observer.observe(resultScope, {
      subtree: true,
      childList: true,
      attributes: true,
      characterData: true
    });
    try {
      onProgress("Gerando o link na sua conta\u2026");
      button.click();
      while (Date.now() < deadline) {
        if (signal.aborted)
          throw new GeneratorError("CANCELLED", "Convers\xE3o cancelada.");
        const outputs = generatedOutputs(resultScope, input, shopee).filter(
          (output) => output.link !== productUrl && (!baseline.some(
            (old) => old.element === output.element && old.link === output.link
          ) || Array.from(touched).some(
            (element) => output.element === element || output.element.contains(element)
          ))
        );
        const links = [...new Set(outputs.map((output) => output.link))];
        if (links.length === 1) return links[0];
        if (links.length > 1)
          throw new GeneratorError(
            "GENERATION_FAILED",
            "O gerador retornou mais de um link. Confira o resultado e use o retorno manual."
          );
        await sleep(250, signal);
      }
      throw new GeneratorError(
        "TIMEOUT",
        "O Mercado Livre n\xE3o confirmou um novo link. Confira login, etiqueta e elegibilidade do produto."
      );
    } finally {
      observer.disconnect();
    }
  }

  // src/affiliate/shopee-helper.ts
  async function start() {
    let context;
    for (let i = 0; i < 4; i++) {
      context = await chrome.runtime.sendMessage({ type: "AFFILIATE_CONTEXT" }).catch(() => null);
      if (isRecord(context) && context.ok === true) break;
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    if (!isRecord(context) || context.ok !== true || !validRequestId(context.requestId)) return;
    const requestId = context.requestId;
    async function send(type, body = {}) {
      const result = await chrome.runtime.sendMessage({ type, requestId, ...body });
      if (!isRecord(result) || result.ok !== true) throw new Error("Solicita\xE7\xE3o n\xE3o confirmada.");
      return result;
    }
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 6e4);
    try {
      if (/\/(?:login|auth)(?:[/?]|$)/i.test(location.pathname) || document.querySelector('input[type="password"],input[autocomplete="one-time-code"]')) {
        await send(context.queued ? "AFFILIATE_RECONNECT" : "AFFILIATE_FAILED");
        return;
      }
      if (context.stage === "resolving") {
        for (let i = 0; i < 60 && !abort.signal.aborted; i++) {
          const product = cleanShopeeProduct(location.href);
          if (product) {
            await send("AFFILIATE_RESOLVE", { productUrl: product });
            return;
          }
          await new Promise((resolve) => setTimeout(resolve, 500));
        }
        throw new Error("Produto n\xE3o identificado.");
      }
      if (context.stage !== "generating" || !shopeeGenerator(location.href)) return;
      const claim = await send("AFFILIATE_CLAIM");
      if (typeof claim.productUrl !== "string") throw new Error("Produto inv\xE1lido.");
      const link = await generateAffiliateLink(
        document,
        location.href,
        claim.productUrl,
        abort.signal,
        () => {
          void send("AFFILIATE_PROGRESS", { step: "generating" }).catch(() => void 0);
        },
        45e3,
        typeof claim.campaignTag === "string" ? claim.campaignTag : void 0,
        true
      );
      await send("AFFILIATE_COMPLETE", { affiliateUrl: link, mode: "automatic" });
    } catch (error) {
      await send(error instanceof GeneratorError && error.code === "LOGIN_REQUIRED" && context.queued ? "AFFILIATE_RECONNECT" : "AFFILIATE_FAILED").catch(() => void 0);
    } finally {
      clearTimeout(timer);
    }
  }
  void start();
})();
