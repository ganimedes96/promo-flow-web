"use strict";
(() => {
  // src/affiliate/shopee/links.ts
  function shopeeLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const u = new URL(value);
      return u.protocol === "https:" && !u.username && !u.password && !u.port && ["shopee.com.br", "www.shopee.com.br", "s.shopee.com.br", "shope.ee", "shp.ee", "affiliate.shopee.com.br"].includes(u.hostname);
    } catch {
      return false;
    }
  }
  function shopeeGenerator(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return u.hostname === "affiliate.shopee.com.br" && u.pathname.replace(/\/$/, "") === "/offer/custom_link";
  }
  function shopeeProduct(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return ["shopee.com.br", "www.shopee.com.br"].includes(u.hostname) && /(?:-i\.\d+\.\d+|\/product\/\d+\/\d+)\/?$/.test(u.pathname);
  }
  function shopeeGenerated(value) {
    if (!shopeeLink(value)) return false;
    const u = new URL(value);
    return ["s.shopee.com.br", "shope.ee", "shp.ee"].includes(u.hostname) && /^\/[a-z0-9_-]+\/?$/i.test(u.pathname) || shopeeProduct(value) && !!u.searchParams.get("af_siteid");
  }

  // src/affiliate/protocol.ts
  var CONVERSION_ERROR_CODES = ["PRODUCT_NOT_FOUND", "MULTIPLE_PRODUCTS", "CAMPAIGN_INVALID", "GENERATOR_FORM", "GENERATOR_TIMEOUT", "GENERATION_FAILED"];
  function conversionErrorCode(value) {
    return typeof value === "string" && CONVERSION_ERROR_CODES.includes(value);
  }
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  var APP_ORIGINS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function appOrigin(value) {
    try {
      const url = new URL(value || "");
      return APP_ORIGINS.some((origin) => origin === url.origin) ? url.origin : null;
    } catch {
      return null;
    }
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }
  function mercadoGeneratorUrl(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return url.hostname === "www.mercadolivre.com.br" && url.pathname.replace(/\/$/, "") === "/afiliados/linkbuilder";
  }
  function pendingAffiliate(value, now = Date.now()) {
    if (!isRecord(value) || !validRequestId(value.requestId) || !validRequestId(value.accountId) || typeof value.origin !== "string" || appOrigin(value.origin) !== value.origin || typeof value.sourceTabId !== "number" || !Number.isInteger(value.sourceTabId) || typeof value.productTabId !== "number" || !Number.isInteger(value.productTabId) || !(mercadoLink(value.sourceUrl) || shopeeLink(value.sourceUrl)) || typeof value.expiresAt !== "number" || value.expiresAt <= now || value.expiresAt > now + AFFILIATE_TTL + 1e3)
      return null;
    if (value.stage !== void 0 && !["resolving", "generating", "failed", "manual"].includes(
      String(value.stage)
    ))
      return null;
    if (value.resolvedUrl !== void 0 && !(mercadoLink(value.resolvedUrl) || shopeeLink(value.resolvedUrl)))
      return null;
    if (value.campaignTag !== void 0 && (typeof value.campaignTag !== "string" || value.campaignTag.length > 100 || /[\x00-\x1f\x7f]/.test(value.campaignTag)))
      return null;
    if (value.linkBuilderUrl !== void 0 && !(mercadoGeneratorUrl(value.linkBuilderUrl) || shopeeGenerator(value.linkBuilderUrl)))
      return null;
    if (value.queue !== void 0 && (!isRecord(value.queue) || !validRequestId(value.queue.offerId) || !validRequestId(value.queue.leaseId) || value.sourceTabId !== -1))
      return null;
    if (value.sourceTabId < 0 && value.queue === void 0) return null;
    if (value.resolvedUrl && mercadoLink(value.sourceUrl) !== mercadoLink(value.resolvedUrl)) return null;
    if (value.linkBuilderUrl && mercadoLink(value.sourceUrl) !== mercadoGeneratorUrl(value.linkBuilderUrl)) return null;
    return {
      queue: isRecord(value.queue) ? {
        offerId: String(value.queue.offerId),
        leaseId: String(value.queue.leaseId)
      } : void 0,
      linkBuilderUrl: typeof value.linkBuilderUrl === "string" ? value.linkBuilderUrl : void 0,
      campaignTag: typeof value.campaignTag === "string" ? value.campaignTag : void 0,
      stage: value.stage,
      resolvedUrl: typeof value.resolvedUrl === "string" ? value.resolvedUrl : void 0,
      autoStarted: value.autoStarted === true,
      requestId: value.requestId,
      accountId: value.accountId,
      origin: value.origin,
      sourceTabId: value.sourceTabId,
      productTabId: value.productTabId,
      sourceUrl: value.sourceUrl,
      expiresAt: value.expiresAt
    };
  }

  // src/affiliate/mercado-livre/links.ts
  function isProductLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br")) && /\bMLBU?-?\d{6,}/i.test(url.pathname);
  }
  function generatedLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "meli.la" || url.hostname === "www.meli.la") && /^\/[a-z0-9]+\/?$/i.test(url.pathname) || (url.searchParams.has("matt_tool") || url.searchParams.has("ref")) && (url.pathname.startsWith("/social/") || isProductLink(value));
  }

  // src/affiliate/platforms.ts
  function affiliateLink(value) {
    return mercadoLink(value) || shopeeLink(value);
  }
  function affiliateProduct(value) {
    return isProductLink(value) || shopeeProduct(value);
  }
  function affiliateGenerated(value) {
    return generatedLink(value) || shopeeGenerated(value);
  }
  function affiliateGenerator(value) {
    return mercadoGeneratorUrl(value) || shopeeGenerator(value);
  }
  function samePlatform(a, b) {
    return mercadoLink(a) && mercadoLink(b) || shopeeLink(a) && shopeeLink(b);
  }

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/services/account.ts
  var apiFor = (destination) => {
    if (!DESTINATIONS.includes(destination))
      throw new Error("Ambiente inv\xE1lido.");
    return destination + "/api/extension-auth";
  };
  async function requestAccount(destination, action, options = {}) {
    const response = await fetch(apiFor(destination) + "/" + action, {
      ...options,
      credentials: "omit",
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(2e4)
    }).catch(() => {
      throw new Error(
        destination === "http://localhost:3000" ? "N\xE3o foi poss\xEDvel acessar o PromoFlow local. Inicie o frontend em localhost:3000 e recarregue a extens\xE3o." : "N\xE3o foi poss\xEDvel acessar o PromoFlow. Verifique sua conex\xE3o e tente novamente."
      );
    });
    if (!response.ok && response.status !== 401) {
      const payload = await response.json().catch(() => null);
      const message = typeof payload === "object" && payload !== null && "message" in payload && typeof payload.message === "string" ? payload.message : "";
      throw new Error(
        response.status === 404 ? "O frontend ainda n\xE3o tem a conex\xE3o atualizada da extens\xE3o. Atualize ou reinicie o PromoFlow e tente novamente." : message || "N\xE3o foi poss\xEDvel consultar o PromoFlow. Tente novamente."
      );
    }
    return response;
  }
  var key = (destination) => "connection:" + destination;
  async function getAccount(destination) {
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    if (!stored) return null;
    if (new Date(stored.expiresAt).getTime() <= Date.now()) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    const response = await requestAccount(destination, "me", {
      headers: { Authorization: "Bearer " + stored.token },
      cache: "no-store"
    });
    if (response.status === 401) {
      await chrome.storage.local.remove(key(destination));
      return null;
    }
    if (!response.ok)
      throw new Error("N\xE3o foi poss\xEDvel consultar sua conex\xE3o. Tente novamente.");
    const payload = await response.json();
    return payload.data.user;
  }
  var random = () => Array.from(
    crypto.getRandomValues(new Uint8Array(32)),
    (v) => v.toString(16).padStart(2, "0")
  ).join("");
  async function connectAccount(destination) {
    apiFor(destination);
    const verifier = random(), state = random();
    const digest = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(verifier)
    );
    const challenge = btoa(String.fromCharCode(...new Uint8Array(digest))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
    const redirectUri = chrome.identity.getRedirectURL("promoflow");
    const url = new URL(destination + "/extension/connect");
    url.searchParams.set("challenge", challenge);
    url.searchParams.set("state", state);
    url.searchParams.set("redirectUri", redirectUri);
    const callback = await chrome.identity.launchWebAuthFlow({
      url: url.toString(),
      interactive: true
    });
    if (!callback) throw new Error("Conex\xE3o cancelada.");
    const returned = new URL(callback);
    if (returned.origin !== new URL(redirectUri).origin || returned.pathname !== "/promoflow")
      throw new Error("Retorno da conex\xE3o inv\xE1lido.");
    const params = new URLSearchParams(returned.hash.slice(1));
    if (params.get("state") !== state) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    if (params.get("error") === "access_denied")
      throw new Error("Conex\xE3o cancelada.");
    if (!params.get("code")) throw new Error("Autoriza\xE7\xE3o inv\xE1lida.");
    const response = await requestAccount(destination, "exchange", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: params.get("code"),
        challenge,
        verifier,
        redirectUri
      })
    });
    if (!response.ok)
      throw new Error("A autoriza\xE7\xE3o expirou. Conecte novamente.");
    const result = await response.json();
    if (!/^[a-f0-9]{64}$/.test(result.data.token))
      throw new Error("Resposta de conex\xE3o inv\xE1lida.");
    await chrome.storage.local.set({ [key(destination)]: result.data });
  }
  async function getPreferences() {
    const saved = (await chrome.storage.local.get("importPreferences")).importPreferences;
    return {
      destination: saved?.destination && DESTINATIONS.includes(saved.destination) ? saved.destination : DESTINATIONS[0],
      target: saved?.target === "central" ? "central" : "offer"
    };
  }
  async function getMercadoLivreStore(destination, marketplace = "MERCADO_LIVRE") {
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    if (!stored || new Date(stored.expiresAt).getTime() <= Date.now())
      return null;
    const response = await requestAccount(destination, "stores", {
      headers: { Authorization: "Bearer " + stored.token }
    });
    if (!response.ok) throw new Error("N\xE3o foi poss\xEDvel consultar suas lojas.");
    const payload = await response.json();
    if (typeof payload !== "object" || payload === null || !("data" in payload) || !Array.isArray(payload.data))
      throw new Error("Resposta de lojas inv\xE1lida.");
    for (const item of payload.data) {
      if (typeof item !== "object" || item === null || item.marketplace !== marketplace)
        continue;
      if (item.campaignTag !== null && (typeof item.campaignTag !== "string" || item.campaignTag.length > 100 || /[\x00-\x1f\x7f]/.test(item.campaignTag)))
        throw new Error("Etiqueta de campanha inv\xE1lida.");
      if (!affiliateGenerator(item.linkBuilderUrl) || marketplace === "SHOPEE" !== shopeeLink(item.linkBuilderUrl)) return null;
      return {
        campaignTag: item.campaignTag,
        linkBuilderUrl: item.linkBuilderUrl
      };
    }
    return null;
  }
  var QueueApiError = class extends Error {
    constructor(status) {
      super("N\xE3o foi poss\xEDvel atualizar a fila de convers\xE3o.");
      this.status = status;
    }
    status;
  };
  async function conversionAccount(destination) {
    apiFor(destination);
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    return stored && new Date(stored.expiresAt).getTime() > Date.now() ? stored.user : null;
  }
  async function conversionRequest(destination, accountId, action, body = {}) {
    const stored = (await chrome.storage.local.get(key(destination)))[key(destination)];
    if (!stored || stored.user.id !== accountId || new Date(stored.expiresAt).getTime() <= Date.now())
      throw new QueueApiError(401);
    const response = await fetch(apiFor(destination) + "/" + action, {
      method: "POST",
      headers: {
        Authorization: "Bearer " + stored.token,
        "Content-Type": "application/json",
        "x-extension-capabilities": "shopee-affiliate-v1"
      },
      body: JSON.stringify(body),
      credentials: "omit",
      cache: "no-store",
      redirect: "error",
      signal: AbortSignal.timeout(2e4)
    });
    if (!response.ok) throw new QueueApiError(response.status);
    const payload = await response.json();
    if (!payload || typeof payload !== "object" || !("data" in payload))
      throw new Error("Resposta da fila inv\xE1lida.");
    return payload.data;
  }

  // src/affiliate/transitions.ts
  var chain = Promise.resolve();
  function serializeAffiliate(operation) {
    const result = chain.then(operation);
    chain = result.catch(() => void 0);
    return result;
  }

  // src/affiliate/queue.ts
  var ALARM = "promoflow-conversions";
  var PRIORITY = "conversion-priority";
  var resultKey = (offerId, leaseId) => "conversion-result:" + offerId + ":" + leaseId;
  function validResult(value) {
    return isRecord(value) && typeof value.origin === "string" && appOrigin(value.origin) === value.origin && validRequestId(value.accountId) && validRequestId(value.offerId) && validRequestId(value.leaseId) && ["SUCCESS", "FAILED", "RECONNECT"].includes(String(value.outcome)) && (value.errorCode === void 0 || conversionErrorCode(value.errorCode)) && (value.outcome !== "SUCCESS" || affiliateGenerated(value.affiliateUrl));
  }
  async function deliver(key3, value) {
    try {
      const response = await conversionRequest(
        value.origin,
        value.accountId,
        "conversion-result",
        {
          offerId: value.offerId,
          leaseId: value.leaseId,
          outcome: value.outcome,
          ...value.affiliateUrl ? { affiliateUrl: value.affiliateUrl } : {},
          ...value.errorCode ? { errorCode: value.errorCode } : {}
        }
      ).catch(async (error) => {
        if (!(error instanceof QueueApiError) || error.status !== 400 || !value.errorCode) throw error;
        return conversionRequest(value.origin, value.accountId, "conversion-result", {
          offerId: value.offerId,
          leaseId: value.leaseId,
          outcome: value.outcome,
          ...value.affiliateUrl ? { affiliateUrl: value.affiliateUrl } : {}
        });
      });
      if (!isRecord(response) || response.accepted !== true)
        throw new Error("Resultado ainda n\xE3o confirmado.");
      await chrome.storage.local.remove(key3);
    } catch (error) {
      if (error instanceof QueueApiError && [400, 401, 403, 404, 409].includes(error.status))
        await chrome.storage.local.remove(key3);
    }
  }
  async function finishQueued(pending, outcome, affiliateUrl, errorCode) {
    if (!pending.queue) return;
    const result = {
      origin: pending.origin,
      accountId: pending.accountId,
      offerId: pending.queue.offerId,
      leaseId: pending.queue.leaseId,
      outcome,
      ...affiliateUrl ? { affiliateUrl } : {},
      ...outcome === "FAILED" && errorCode ? { errorCode } : {}
    };
    if (!validResult(result)) throw new Error("Resultado de convers\xE3o inv\xE1lido.");
    const key3 = resultKey(result.offerId, result.leaseId);
    await chrome.storage.local.set({ [key3]: result });
    await chrome.storage.session.remove("affiliate:" + pending.productTabId);
    await deliver(key3, result);
    await chrome.tabs.remove(pending.productTabId).catch(() => void 0);
  }
  async function tick() {
    const local = await chrome.storage.local.get(null);
    for (const [name, value] of Object.entries(local)) {
      if (!name.startsWith("conversion-result:")) continue;
      if (validResult(value)) await deliver(name, value);
      else await chrome.storage.local.remove(name);
    }
    if (Object.keys(await chrome.storage.local.get(null)).some(
      (name) => name.startsWith("conversion-result:")
    ))
      return;
    const session = await chrome.storage.session.get(null);
    for (const [name, value] of Object.entries(session)) {
      if (!name.startsWith("affiliate:")) continue;
      const pending2 = pendingAffiliate(value);
      if (pending2) {
        if (pending2.queue && (await conversionAccount(pending2.origin))?.id !== pending2.accountId) {
          await finishQueued(pending2, "FAILED");
          continue;
        }
        if (pending2.queue && !await chrome.tabs.get(pending2.productTabId).catch(() => null))
          await finishQueued(pending2, "FAILED");
        else return;
      } else if (isRecord(value) && typeof value.expiresAt === "number") {
        const expired = pendingAffiliate(value, value.expiresAt - 1);
        if (expired?.queue) {
          await finishQueued(expired, "FAILED");
          return;
        }
      }
    }
    const { destination } = await getPreferences();
    const account = await conversionAccount(destination);
    if (!account) return;
    const payload = await conversionRequest(
      destination,
      account.id,
      "conversion-claim",
      (() => {
        const priority2 = local[PRIORITY];
        return isRecord(priority2) && priority2.origin === destination && priority2.accountId === account.id && validRequestId(priority2.offerId) && typeof priority2.expiresAt === "number" && priority2.expiresAt > Date.now() ? { offerId: priority2.offerId } : {};
      })()
    );
    if (!isRecord(payload) || payload.job === null) return;
    const job = payload.job;
    if (!isRecord(job) || !validRequestId(job.offerId) || !validRequestId(job.leaseId) || !affiliateLink(job.sourceUrl) || !affiliateGenerator(job.linkBuilderUrl) || !samePlatform(job.sourceUrl, job.linkBuilderUrl) || typeof job.expiresAt !== "string" || job.campaignTag !== null && job.campaignTag !== void 0 && (typeof job.campaignTag !== "string" || job.campaignTag.length > 100 || /[\x00-\x1f\x7f]/.test(job.campaignTag)))
      throw new Error("Reserva de convers\xE3o inv\xE1lida.");
    const expiresAt = Date.parse(job.expiresAt);
    if (!Number.isFinite(expiresAt) || expiresAt <= Date.now() || expiresAt > Date.now() + AFFILIATE_TTL + 1e3)
      throw new Error("Prazo de convers\xE3o inv\xE1lido.");
    const stored = await conversionAccount(destination);
    if (stored?.id !== account.id) return;
    const tab = await chrome.tabs.create({ url: "about:blank", active: false });
    if (tab.id === void 0)
      throw new Error("N\xE3o foi poss\xEDvel abrir o gerador.");
    const pending = {
      queue: { offerId: job.offerId, leaseId: job.leaseId },
      requestId: crypto.randomUUID(),
      accountId: account.id,
      origin: destination,
      sourceTabId: -1,
      productTabId: tab.id,
      sourceUrl: job.sourceUrl,
      linkBuilderUrl: job.linkBuilderUrl,
      campaignTag: typeof job.campaignTag === "string" ? job.campaignTag : void 0,
      stage: "resolving",
      autoStarted: false,
      expiresAt
    };
    await chrome.storage.session.set({ ["affiliate:" + tab.id]: pending });
    const priority = local[PRIORITY];
    if (isRecord(priority) && priority.accountId === account.id && priority.origin === destination && priority.offerId === job.offerId)
      await chrome.storage.local.remove(PRIORITY);
    await chrome.tabs.update(tab.id, { url: pending.sourceUrl }).catch(async () => {
      await finishQueued(pending, "FAILED");
    });
  }
  async function wakeConversionQueue(origin, accountId, offerId) {
    const preferences = await getPreferences();
    if (preferences.destination !== origin)
      return {
        ok: false,
        error: "Selecione este mesmo ambiente nas configura\xE7\xF5es da extens\xE3o."
      };
    const account = await conversionAccount(origin);
    if (account?.id !== accountId)
      return {
        ok: false,
        error: "Conecte a extens\xE3o \xE0 mesma conta do PromoFlow antes de converter."
      };
    await chrome.storage.local.set({
      [PRIORITY]: {
        origin,
        accountId,
        offerId,
        expiresAt: Date.now() + AFFILIATE_TTL
      }
    });
    try {
      await tick();
    } catch (error) {
      return {
        ok: false,
        error: error instanceof QueueApiError && [401, 403].includes(error.status) ? "Reconecte sua conta na extens\xE3o do PromoFlow." : "N\xE3o foi poss\xEDvel consultar a fila. Confira sua conex\xE3o e se a API est\xE1 atualizada."
      };
    }
    const pending = Object.values(await chrome.storage.session.get(null)).map((value) => pendingAffiliate(value)).filter(
      (value) => value && value.origin === origin && value.accountId === accountId
    );
    return {
      ok: true,
      state: pending.some((value) => value?.queue?.offerId === offerId) ? "CONVERTING" : pending.length ? "BUSY" : "WAITING"
    };
  }
  function installConversionQueue() {
    const run = () => {
      void serializeAffiliate(tick).catch(() => void 0);
    };
    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === ALARM) run();
    });
    const ensure = async () => {
      if (!await chrome.alarms.get(ALARM))
        await chrome.alarms.create(ALARM, { periodInMinutes: 1 });
      run();
    };
    chrome.runtime.onStartup.addListener(() => {
      void ensure();
    });
    chrome.runtime.onInstalled.addListener(() => {
      void ensure();
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && (changes.importPreferences || Object.keys(changes).some((key3) => key3.startsWith("connection:"))))
        run();
    });
    void ensure().catch(() => void 0);
  }

  // src/affiliate/watch-copy.ts
  function watchAffiliateCopy(requestId, expiresAt) {
    const valid = (value) => {
      if (value.length > 2048) return false;
      try {
        const url = new URL(value);
        return url.protocol === "https:" && !url.username && !url.password && !url.port && (url.hostname === "meli.la" || url.hostname === "www.meli.la" || url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br"));
      } catch {
        return false;
      }
    };
    const notify = (value) => {
      const link = value.trim();
      if (Date.now() < expiresAt && valid(link)) window.postMessage({ type: "PROMOFLOW_ML_LINK_COPIED", requestId, link }, location.origin);
    };
    const clipboard = navigator.clipboard;
    const original = clipboard?.writeText;
    const wrapped = original ? async (value) => {
      await original.call(clipboard, value);
      notify(value);
    } : void 0;
    try {
      if (wrapped) Object.defineProperty(clipboard, "writeText", { configurable: true, value: wrapped });
    } catch {
    }
    const copy = (event) => {
      const value = event.clipboardData?.getData("text/plain");
      if (value) notify(value);
    };
    const finish = () => {
      document.removeEventListener("copy", copy);
      window.removeEventListener("message", stop);
      if (wrapped && clipboard.writeText === wrapped) {
        try {
          Object.defineProperty(clipboard, "writeText", { configurable: true, value: original });
        } catch {
        }
      }
    };
    const stop = (event) => {
      if (event.source === window && event.origin === location.origin && event.data?.type === "PROMOFLOW_ML_STOP_COPY" && event.data?.requestId === requestId) finish();
    };
    document.addEventListener("copy", copy);
    window.addEventListener("message", stop);
    setTimeout(finish, Math.max(0, expiresAt - Date.now()));
  }

  // src/affiliate/background.ts
  var key2 = (tabId) => `affiliate:${tabId}`;
  async function read(tabId) {
    return pendingAffiliate(
      (await chrome.storage.session.get(key2(tabId)))[key2(tabId)]
    );
  }
  async function save(pending) {
    await chrome.storage.session.set({ [key2(pending.productTabId)]: pending });
  }
  async function progress(pending, text, status = "pending") {
    if (pending.queue) return;
    const source = await chrome.tabs.get(pending.sourceTabId).catch(() => null);
    if (source && appOrigin(source.url) === pending.origin)
      await chrome.tabs.sendMessage(pending.sourceTabId, {
        type: "AFFILIATE_PROGRESS",
        requestId: pending.requestId,
        accountId: pending.accountId,
        text,
        status
      }).catch(() => void 0);
  }
  async function handle(message, sender) {
    const tabId = sender.tab?.id;
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || tabId === void 0)
      throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
    if (message.type === "CONVERSION_RETRY") {
      const origin = appOrigin(sender.url);
      if (!origin || !validRequestId(message.accountId) || !validRequestId(message.offerId))
        throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
      const account = await getAccount(origin);
      if (account?.id !== message.accountId)
        return {
          ok: false,
          error: "Conecte a extens\xE3o \xE0 mesma conta do PromoFlow."
        };
      return wakeConversionQueue(origin, message.accountId, message.offerId);
    }
    if (message.type === "EXTENSION_STATUS") {
      const origin = appOrigin(sender.url);
      if (!origin) throw new Error("Ambiente inv\xE1lido.");
      const account = await getAccount(origin);
      return { ok: true, accountId: account?.id ?? null };
    }
    if (message.type === "AFFILIATE_ABORT") {
      const origin = appOrigin(sender.url);
      if (!origin || !validRequestId(message.requestId) || !validRequestId(message.accountId))
        throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
      const values = await chrome.storage.session.get(null);
      for (const [name, value] of Object.entries(values)) {
        const job = name.startsWith("affiliate:") ? pendingAffiliate(value) : null;
        if (job && job.sourceTabId === tabId && job.origin === origin && job.accountId === message.accountId && job.requestId === message.requestId) {
          await chrome.storage.session.remove(name);
          await chrome.tabs.remove(job.productTabId).catch(() => void 0);
        }
      }
      return { ok: true };
    }
    if (message.type === "AFFILIATE_BEGIN") {
      const origin = appOrigin(sender.url);
      if (!origin || !validRequestId(message.requestId) || !validRequestId(message.accountId) || !affiliateLink(message.productUrl))
        throw new Error("Produto ou ambiente inv\xE1lido.");
      const account = await getAccount(origin);
      if (!account || account.id !== message.accountId)
        throw new Error(
          "Conecte a extens\xE3o \xE0 mesma conta e ambiente do formul\xE1rio."
        );
      const configuration = await getMercadoLivreStore(
        origin,
        shopeeLink(message.productUrl) ? "SHOPEE" : "MERCADO_LIVRE"
      );
      if (!configuration || !affiliateGenerator(configuration.linkBuilderUrl))
        return {
          ok: false,
          error: "Cadastre a loja na p\xE1gina Lojas do PromoFlow antes de converter."
        };
      const stored = await chrome.storage.session.get(null);
      if (Object.values(stored).some((value) => pendingAffiliate(value)?.queue))
        return {
          ok: false,
          error: "A extens\xE3o est\xE1 processando a fila autom\xE1tica. Aguarde a convers\xE3o atual."
        };
      const existing = Object.values(stored).map((value) => pendingAffiliate(value)).find(
        (job) => job && job.sourceTabId === tabId && job.requestId === message.requestId && job.accountId === account.id && job.origin === origin
      );
      if (existing) return { ok: true };
      const stale = Object.entries(stored).filter(
        ([name, value]) => name.startsWith("affiliate:") && (!pendingAffiliate(value) || isRecord(value) && value.sourceTabId === tabId)
      ).map(([name]) => name);
      if (stale.length) {
        await chrome.storage.session.remove(stale);
        for (const name of stale) {
          const job = pendingAffiliate(stored[name]);
          if (job && job.sourceTabId === tabId)
            await chrome.tabs.remove(job.productTabId).catch(() => void 0);
        }
      }
      const tab = await chrome.tabs.create({ url: "about:blank", active: false });
      if (tab.id === void 0)
        throw new Error("N\xE3o foi poss\xEDvel abrir o produto.");
      await save({
        requestId: message.requestId,
        accountId: account.id,
        origin,
        sourceTabId: tabId,
        productTabId: tab.id,
        sourceUrl: message.productUrl,
        campaignTag: configuration.campaignTag || void 0,
        linkBuilderUrl: configuration.linkBuilderUrl,
        stage: "resolving",
        autoStarted: false,
        expiresAt: Date.now() + AFFILIATE_TTL
      });
      await chrome.tabs.update(tab.id, { url: message.productUrl });
      return { ok: true };
    }
    const pending = await read(tabId);
    if (!pending || !sender.url || !affiliateLink(sender.url) || !samePlatform(sender.url, pending.sourceUrl))
      throw new Error(
        "Solicita\xE7\xE3o expirada. Volte ao formul\xE1rio e tente novamente."
      );
    if (pending.queue && (await conversionAccount(pending.origin))?.id !== pending.accountId)
      throw new Error("Conecte novamente a extens\xE3o \xE0 conta desta oferta.");
    if (message.type === "AFFILIATE_RECONNECT" && pending.queue) {
      await finishQueued(pending, "RECONNECT");
      return { ok: true };
    }
    if (message.type === "AFFILIATE_CONTEXT")
      return {
        ok: true,
        requestId: pending.requestId,
        queued: !!pending.queue,
        stage: pending.stage || "manual",
        campaignTag: pending.campaignTag,
        productUrl: pending.resolvedUrl || pending.sourceUrl,
        expiresAt: pending.expiresAt
      };
    if (message.requestId !== pending.requestId)
      throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
    if (message.type === "AFFILIATE_RESOLVE") {
      if (pending.stage !== "resolving" || !affiliateProduct(message.productUrl) || !samePlatform(message.productUrl, pending.sourceUrl) || !(shopeeLink(sender.url) || new URL(sender.url).hostname === "mercadolivre.com.br" || new URL(sender.url).hostname.endsWith(".mercadolivre.com.br")))
        throw new Error("N\xE3o foi poss\xEDvel identificar o produto desta p\xE1gina.");
      pending.resolvedUrl = message.productUrl;
      pending.stage = "generating";
      pending.autoStarted = false;
      await save(pending);
      await progress(
        pending,
        "Produto identificado. Abrindo o gerador da sua conta\u2026"
      );
      if (!pending.linkBuilderUrl || !affiliateGenerator(pending.linkBuilderUrl))
        throw new Error("Configure a URL do gerador em Lojas.");
      await chrome.tabs.update(tabId, { url: pending.linkBuilderUrl });
      return { ok: true };
    }
    if (message.type === "AFFILIATE_CLAIM") {
      if (pending.stage !== "generating" || !affiliateGenerator(sender.url) || !affiliateProduct(pending.resolvedUrl))
        throw new Error("Inicie a convers\xE3o pelo formul\xE1rio do PromoFlow.");
      if (pending.autoStarted)
        return {
          ok: false,
          error: "Esta convers\xE3o j\xE1 foi iniciada. Volte ao formul\xE1rio para tentar novamente."
        };
      pending.autoStarted = true;
      await save(pending);
      return {
        ok: true,
        productUrl: pending.resolvedUrl,
        campaignTag: pending.campaignTag
      };
    }
    if (message.type === "AFFILIATE_PROGRESS") {
      const text = message.step === "filling" ? "Preenchendo o produto no gerador\u2026" : "Gerando o link na sua conta da loja\u2026";
      await progress(pending, text);
      return { ok: true };
    }
    if (message.type === "AFFILIATE_ATTENTION") {
      if (pending.queue) {
        await finishQueued(pending, "FAILED", void 0, "MULTIPLE_PRODUCTS");
        return { ok: true };
      }
      await chrome.tabs.update(tabId, { active: true }).catch(() => void 0);
      await progress(
        pending,
        "Escolha o produto correspondente \xE0 oferta no assistente do Mercado Livre.",
        "error"
      );
      return { ok: true };
    }
    if (message.type === "AFFILIATE_RETRY") {
      if (pending.stage !== "failed")
        throw new Error("A convers\xE3o ainda est\xE1 em andamento.");
      if (pending.resolvedUrl && (!pending.linkBuilderUrl || !affiliateGenerator(pending.linkBuilderUrl)))
        throw new Error("Configure a URL do gerador em Lojas.");
      pending.stage = pending.resolvedUrl ? "generating" : "resolving";
      pending.autoStarted = false;
      await save(pending);
      await progress(pending, "Retomando a convers\xE3o do seu link\u2026");
      await chrome.tabs.update(tabId, {
        url: pending.resolvedUrl ? pending.linkBuilderUrl : pending.sourceUrl
      });
      return { ok: true };
    }
    if (message.type === "AFFILIATE_FAILED") {
      if (pending.queue) {
        await finishQueued(pending, "FAILED", void 0, conversionErrorCode(message.errorCode) ? message.errorCode : void 0);
        return { ok: true };
      }
      pending.stage = "failed";
      await save(pending);
      await chrome.tabs.update(tabId, { active: true }).catch(() => void 0);
      await progress(
        pending,
        "N\xE3o foi poss\xEDvel converter automaticamente. Confira o assistente na loja ou tente novamente.",
        "error"
      );
      return { ok: true };
    }
    if (message.type === "AFFILIATE_CANCEL") {
      if (pending.queue) {
        await finishQueued(pending, "FAILED");
        return { ok: true };
      }
      await progress(
        pending,
        "Convers\xE3o cancelada. Seus dados foram preservados.",
        "error"
      );
      await chrome.storage.session.remove(key2(tabId));
      return { ok: true };
    }
    if (message.type === "AFFILIATE_WATCH_COPY") {
      await chrome.scripting.executeScript({
        target: { tabId },
        world: "MAIN",
        func: watchAffiliateCopy,
        args: [pending.requestId, pending.expiresAt]
      });
      return { ok: true };
    }
    if (message.type === "AFFILIATE_COMPLETE" && affiliateGenerated(message.affiliateUrl) && samePlatform(message.affiliateUrl, pending.sourceUrl)) {
      const automatic = message.mode === "automatic";
      if (automatic && (!affiliateGenerator(sender.url) || pending.stage !== "generating" || !pending.autoStarted || !(affiliateGenerated(message.affiliateUrl) && samePlatform(message.affiliateUrl, pending.sourceUrl))))
        throw new Error("O gerador n\xE3o confirmou um link v\xE1lido.");
      if (message.affiliateUrl === pending.sourceUrl || message.affiliateUrl === pending.resolvedUrl)
        throw new Error("Esse \xE9 o link original. Gere seu pr\xF3prio link na loja.");
      if (pending.queue) {
        if (!automatic)
          throw new Error(
            "A fila aceita somente links confirmados pelo gerador autom\xE1tico."
          );
        await finishQueued(pending, "SUCCESS", message.affiliateUrl);
        return { ok: true };
      }
      const source = await chrome.tabs.get(pending.sourceTabId);
      const account = await getAccount(pending.origin);
      if (appOrigin(source.url) !== pending.origin || !account || account.id !== pending.accountId)
        throw new Error(
          "Sua conta ou formul\xE1rio mudou. Inicie novamente no PromoFlow."
        );
      await chrome.tabs.sendMessage(pending.sourceTabId, {
        type: "AFFILIATE_RESULT",
        requestId: pending.requestId,
        accountId: pending.accountId,
        affiliateUrl: message.affiliateUrl,
        mode: automatic ? "automatic" : "manual"
      });
      await chrome.storage.session.remove(key2(tabId));
      if (automatic) await chrome.tabs.remove(tabId).catch(() => void 0);
      else await chrome.tabs.update(pending.sourceTabId, { active: true });
      return { ok: true };
    }
    throw new Error("Solicita\xE7\xE3o inv\xE1lida.");
  }
  var messages = [
    "CONVERSION_RETRY",
    "EXTENSION_STATUS",
    "AFFILIATE_BEGIN",
    "AFFILIATE_ABORT",
    "AFFILIATE_RETRY",
    "AFFILIATE_ATTENTION",
    "AFFILIATE_CONTEXT",
    "AFFILIATE_RESOLVE",
    "AFFILIATE_CLAIM",
    "AFFILIATE_PROGRESS",
    "AFFILIATE_FAILED",
    "AFFILIATE_RECONNECT",
    "AFFILIATE_CANCEL",
    "AFFILIATE_COMPLETE",
    "AFFILIATE_WATCH_COPY"
  ];
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (!isRecord(message) || !messages.includes(String(message.type)))
      return false;
    const operation = serializeAffiliate(() => handle(message, sender));
    void operation.then(respond).catch(
      () => respond({
        ok: false,
        error: "N\xE3o foi poss\xEDvel concluir a convers\xE3o. Confira a conta conectada, o produto e tente novamente."
      })
    );
    return true;
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    void serializeAffiliate(async () => {
      const values = await chrome.storage.session.get(null);
      const keys = [];
      const auxiliaryTabs = [];
      for (const [name, value] of Object.entries(values)) {
        if (!name.startsWith("affiliate:")) continue;
        const pending = pendingAffiliate(value);
        if (!pending || pending.sourceTabId === tabId || pending.productTabId === tabId) {
          if (pending?.queue && pending.productTabId === tabId) {
            await finishQueued(pending, "FAILED");
            continue;
          }
          if (pending && pending.productTabId === tabId)
            await progress(
              pending,
              "A aba do gerador foi fechada. Voc\xEA pode tentar novamente.",
              "error"
            );
          keys.push(name);
          if (pending?.sourceTabId === tabId)
            auxiliaryTabs.push(pending.productTabId);
        }
      }
      if (keys.length) await chrome.storage.session.remove(keys);
      for (const id of auxiliaryTabs)
        await chrome.tabs.remove(id).catch(() => void 0);
    }).catch(() => void 0);
  });
  installConversionQueue();

  // src/shared/urls.ts
  function isShopeeHost(host) {
    return host === "shopee.com.br" || host.endsWith(".shopee.com.br");
  }
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host) || isShopeeHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "susercontent.com",
      "shopee.com.br",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || [
        "meli.la",
        "www.meli.la",
        "amzn.to",
        "a.co",
        "shope.ee",
        "shp.ee"
      ].some(
        (domain) => url.hostname === domain || url.hostname.endsWith("." + domain)
      ));
    } catch {
      return false;
    }
  }

  // src/shared/value.ts
  function isRecord2(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord2(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord2(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return (draft.sourceCategory === void 0 || typeof draft.sourceCategory === "string" && draft.sourceCategory.length <= 300) && typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre, na Amazon Brasil ou na Shopee."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre, na Amazon Brasil ou na Shopee. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const read2 = async () => {
      const [injection] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["collector.js"]
      });
      const data2 = injection?.result;
      if (!isCapturedProduct(data2))
        throw new Error(
          "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
        );
      return data2;
    };
    let data = await read2();
    if (isShopeeHost(new URL(tab.url).hostname) && data.draft.currentPrice === null) {
      const identity = (url) => new URL(url).pathname.match(/(?:-i\.|\/product\/)(\d+)[./](\d+)/)?.slice(1).join(":");
      const initial = identity(data.draft.sourceUrl);
      for (let attempt = 0; attempt < 3 && data.draft.currentPrice === null; attempt++) {
        await new Promise((resolve) => setTimeout(resolve, 800));
        const next = await read2();
        if (!initial || identity(next.draft.sourceUrl) !== initial)
          throw new Error(
            "O produto mudou durante a captura. Capture novamente o an\xFAncio desejado."
          );
        data = next;
      }
    }
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const account = await getAccount(options.destination);
    if (!account)
      throw new Error("Conecte sua conta pelo bot\xE3o Conectar ao PromoFlow.");
    if (options.target === "central" && account.role !== "admin")
      throw new Error("A central \xE9 exclusiva do administrador.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil, Shopee ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured,
      accountId: account.id,
      target: options.target || "offer",
      draft: { ...captured.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/background/index.ts
  var capturing = false;
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "capture-product" || capturing) return;
    capturing = true;
    void (async () => {
      try {
        await chrome.action.setBadgeText({ text: "..." });
        const product = await captureActiveProduct(tab);
        await openDraft(product, {
          ...await getPreferences(),
          affiliateUrl: "",
          couponCode: ""
        });
        await chrome.action.setBadgeText({ text: "" });
        await chrome.action.setTitle({
          title: "Importar produto para o PromoFlow"
        });
      } catch (error) {
        await chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
        await chrome.action.setBadgeText({ text: "!" });
        await chrome.action.setTitle({
          title: "Falha ao importar: " + errorMessage(error, "Abra um produto e tente novamente.").slice(
            0,
            220
          )
        });
      } finally {
        capturing = false;
      }
    })().catch((error) => {
      capturing = false;
      console.error(errorMessage(error, "Falha ao importar produto."));
    });
  });
  void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  var connecting = false;
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL("popup.html"))
      return false;
    if (typeof message !== "object" || message === null || !("type" in message) || message.type !== "CONNECT_ACCOUNT" || !("destination" in message) || typeof message.destination !== "string")
      return false;
    if (connecting) {
      respond({ ok: false, error: "J\xE1 existe uma conex\xE3o em andamento." });
      return false;
    }
    connecting = true;
    void connectAccount(message.destination).then(() => respond({ ok: true })).catch(
      (error) => respond({
        ok: false,
        error: errorMessage(error, "N\xE3o foi poss\xEDvel conectar.")
      })
    ).finally(() => {
      connecting = false;
    });
    return true;
  });
})();
