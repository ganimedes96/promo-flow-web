"use strict";
(() => {
  // src/affiliate/protocol.ts
  var AFFILIATE_TTL = 10 * 60 * 1e3;
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function validRequestId(value) {
    return typeof value === "string" && /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i.test(value);
  }
  function mercadoLink(value) {
    if (typeof value !== "string" || value.length > 2048) return false;
    try {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      return url.protocol === "https:" && !url.username && !url.password && !url.port && (host === "meli.la" || host === "www.meli.la" || host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br"));
    } catch {
      return false;
    }
  }
  function mercadoGeneratorUrl(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return url.hostname === "www.mercadolivre.com.br" && url.pathname.replace(/\/$/, "") === "/afiliados/linkbuilder";
  }

  // src/affiliate/mercado-livre/dom.ts
  function isVisible(element) {
    if (element.closest('[hidden],[aria-hidden="true"]')) return false;
    for (let current = element; current; current = current.parentElement) {
      const view = current.ownerDocument.defaultView;
      const style = typeof view?.getComputedStyle === "function" ? view.getComputedStyle(current) : current instanceof HTMLElement ? current.style : null;
      if (style && (style.display === "none" || style.visibility === "hidden"))
        return false;
    }
    return true;
  }

  // src/affiliate/mercado-livre/links.ts
  function isLinkBuilder(value) {
    return mercadoGeneratorUrl(value);
  }
  function isProductLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br")) && /\bMLBU?-?\d{6,}/i.test(url.pathname);
  }
  function generatedLink(value) {
    if (!mercadoLink(value)) return false;
    const url = new URL(value);
    return (url.hostname === "meli.la" || url.hostname === "www.meli.la") && /^\/[a-z0-9]+\/?$/i.test(url.pathname) || (url.searchParams.has("matt_tool") || url.searchParams.has("ref")) && (url.pathname.startsWith("/social/") || isProductLink(value));
  }
  function productTarget(value, base) {
    try {
      const url = new URL(value, base);
      if (isProductLink(url.href)) return url.href;
      if (!mercadoLink(url.href)) return null;
      for (const key of ["url", "target", "destination", "redirect_url"]) {
        const nested = url.searchParams.get(key);
        if (nested && isProductLink(nested)) return nested;
      }
    } catch {
    }
    return null;
  }
  function productKey(value) {
    const url = new URL(value);
    return (url.searchParams.get("wid") || url.pathname.match(/MLBU?-?\d+/i)?.[0]?.replace("-", "") || url.pathname) + ":" + (url.searchParams.get("attributes") || url.searchParams.get("variation") || "");
  }
  function socialProducts(doc, currentUrl) {
    if (!mercadoLink(currentUrl) || !new URL(currentUrl).pathname.startsWith("/social/"))
      return [];
    const scope = doc.querySelector('main,[role="main"]') || doc.body;
    const products = /* @__PURE__ */ new Map(), primary = /* @__PURE__ */ new Map();
    for (const element of Array.from(
      scope.querySelectorAll(
        "a[href],button[data-href],button[data-url]"
      )
    )) {
      if (!isVisible(element) || element.closest("nav,footer,aside")) continue;
      const target = productTarget(
        element.getAttribute("href") || element.getAttribute("data-href") || element.getAttribute("data-url") || "",
        currentUrl
      );
      if (!target) continue;
      const text = (element.getAttribute("aria-label") || element.textContent || "").replace(/\s+/g, " ").trim();
      const label = (element.getAttribute("title") || element.querySelector("img[alt]")?.alt || text || "Produto do Mercado Livre").slice(0, 160);
      const item = { url: target, label }, key = productKey(target);
      if (!products.has(key)) products.set(key, item);
      const action = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
      if (/^(?:ir (?:para (?:o )?|ao )produto|ver (?:o )?produto|comprar(?: agora| no mercado livre)?|ver oferta)$/.test(
        action
      ))
        primary.set(key, item);
    }
    return primary.size === 1 ? [...primary.values()] : [...products.values()];
  }
  function productFromPage(doc, currentUrl) {
    if (isProductLink(currentUrl)) return currentUrl;
    for (const value of [
      doc.querySelector('link[rel="canonical"]')?.href,
      doc.querySelector('meta[property="og:url"]')?.content
    ])
      if (isProductLink(value)) return value;
    const products = socialProducts(doc, currentUrl);
    return products.length === 1 ? products[0].url : null;
  }
  function intermediateProductAction(doc, currentUrl) {
    if (!mercadoLink(currentUrl)) return null;
    const url = new URL(currentUrl);
    if (!(url.hostname === "mercadolivre.com.br" || url.hostname.endsWith(".mercadolivre.com.br")) || !url.pathname.startsWith("/social/"))
      return null;
    const scope = doc.querySelector('main,[role="main"]') || doc.body;
    const candidates = Array.from(
      scope.querySelectorAll('a,button,[role="button"]')
    ).filter((element) => {
      if (!isVisible(element) || element.closest("nav,footer,aside") || element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true")
        return false;
      const text = (element.getAttribute("aria-label") || element.textContent || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
      if (!/^(?:ir (?:para (?:o )?|ao )produto|ver (?:o )?produto|acessar (?:o )?produto)$/.test(
        text
      ))
        return false;
      const href = element.getAttribute("href");
      if (href && !href.startsWith("#")) {
        try {
          if (!mercadoLink(new URL(href, currentUrl).href)) return false;
        } catch {
          return false;
        }
      }
      return true;
    });
    const unique = candidates.filter(
      (element) => !candidates.some((other) => other !== element && other.contains(element))
    );
    return unique.length === 1 ? unique[0] : null;
  }

  // src/affiliate/mercado-livre/generator.ts
  var GeneratorError = class extends Error {
    constructor(code, message) {
      super(message);
      this.code = code;
    }
    code;
  };
  function normalize(text) {
    return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/\s+/g, " ").trim().toLowerCase();
  }
  function name(element, doc) {
    const labelledBy = element.getAttribute("aria-labelledby")?.split(/\s+/).map((id) => doc.getElementById(id)?.textContent || "").join(" ");
    const label = element.id ? Array.from(doc.querySelectorAll("label")).find(
      (label2) => label2.getAttribute("for") === element.id
    )?.textContent : "";
    return normalize(
      [
        element.getAttribute("aria-label"),
        element.getAttribute("placeholder"),
        labelledBy,
        label
      ].filter(Boolean).join(" ")
    );
  }
  function locateGenerator(doc) {
    const inputs = Array.from(
      doc.querySelectorAll(
        "input,textarea"
      )
    ).filter(
      (element) => isVisible(element) && !element.disabled && !element.readOnly && (element instanceof HTMLTextAreaElement || ["url", "text", "search"].includes(element.type || "text")) && /(?:url|link|endereco).*(?:produto|insira|cole)|(?:insira|cole).*(?:url|link)|^url$/.test(
        name(element, doc)
      )
    );
    if (inputs.length > 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "H\xE1 mais de um campo de produto. Preencha pelo gerador e use o retorno manual."
      );
    const input = inputs[0];
    if (!input) return null;
    const scope = input.closest("form") || doc.querySelector("main") || doc.body;
    const buttons = Array.from(
      scope.querySelectorAll(
        'button,input[type="submit"]'
      )
    ).filter(
      (button) => isVisible(button) && /^(?:gerar|gerar (?:o |meu |seu )?(?:link|links|produto recomendado|produtos recomendados)(?: de afiliado)?)$/.test(
        normalize(
          button.getAttribute("aria-label") || (button instanceof HTMLInputElement ? button.value : button.textContent) || ""
        )
      )
    );
    if (buttons.length > 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "N\xE3o foi poss\xEDvel identificar com seguran\xE7a o bot\xE3o de gerar link."
      );
    return buttons[0] ? { input, button: buttons[0], scope } : null;
  }
  function generatedOutputs(scope, input) {
    const outputs = [];
    const add = (element, value) => {
      const links = value.match(/https:\/\/[^\s<>"']+/g) || [];
      for (const candidate of links) {
        const link = candidate.replace(/[),.;]+$/, "");
        if (generatedLink(link) && !outputs.some(
          (output) => output.element === element && output.link === link
        ))
          outputs.push({ element, link });
      }
    };
    for (const element of Array.from(
      scope.querySelectorAll(
        'input[readonly],textarea[readonly],[role="textbox"][aria-readonly="true"]'
      )
    )) {
      if (element !== input && isVisible(element))
        add(
          element,
          "value" in element ? String(element.value) : element.textContent || ""
        );
    }
    for (const button of Array.from(scope.querySelectorAll("button"))) {
      if (!isVisible(button) || !/^copiar(?: (?:o )?link)?$/.test(
        normalize(
          button.getAttribute("aria-label") || button.textContent || ""
        )
      ))
        continue;
      let parent = button.parentElement;
      for (let depth = 0; parent && depth < 3; depth++, parent = parent.parentElement) {
        for (const element of Array.from(
          parent.querySelectorAll("a[href],p,span,code")
        )) {
          if (isVisible(element))
            add(
              element,
              element instanceof HTMLAnchorElement ? element.href : element.textContent || ""
            );
        }
        if (outputs.length) break;
      }
    }
    return outputs;
  }
  function sleep(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new GeneratorError("CANCELLED", "Convers\xE3o cancelada."));
        return;
      }
      const cancel = () => {
        clearTimeout(timer);
        signal.removeEventListener("abort", cancel);
        reject(new GeneratorError("CANCELLED", "Convers\xE3o cancelada."));
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", cancel);
        resolve();
      }, ms);
      signal.addEventListener("abort", cancel, { once: true });
    });
  }
  async function applyCampaignTag(doc, tag, signal) {
    if (!tag?.trim()) return;
    const expected = normalize(tag);
    const matches = Array.from(
      doc.querySelectorAll('select,[role="combobox"]')
    ).filter(
      (element) => isVisible(element) && /etiqueta|campanha/.test(name(element, doc))
    );
    if (matches.length !== 1)
      throw new GeneratorError(
        "AMBIGUOUS_FORM",
        "N\xE3o foi poss\xEDvel localizar a etiqueta cadastrada em Lojas. Confira o gerador antes de continuar."
      );
    const control = matches[0];
    if (control.tagName === "SELECT") {
      const select = control;
      const options = Array.from(select.options).filter(
        (option) => !option.disabled && normalize(option.textContent || "") === expected
      );
      if (select.disabled || options.length !== 1)
        throw new GeneratorError(
          "GENERATION_FAILED",
          "A etiqueta cadastrada em Lojas n\xE3o est\xE1 dispon\xEDvel nesta conta do Mercado Livre."
        );
      select.value = options[0].value;
      select.dispatchEvent(new Event("input", { bubbles: true }));
      select.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(250, signal);
      if (normalize(select.selectedOptions[0]?.textContent || "") !== expected)
        throw new GeneratorError(
          "GENERATION_FAILED",
          "O gerador n\xE3o confirmou a etiqueta. Confira sua configura\xE7\xE3o em Lojas."
        );
      return;
    }
    if (normalize(control.textContent || "") === expected || normalize(control.getAttribute("value") || "") === expected)
      return;
    control.click();
    for (let attempt = 0; attempt < 12; attempt++) {
      const options = Array.from(
        doc.querySelectorAll('[role="option"]')
      ).filter(
        (option) => isVisible(option) && option.getAttribute("aria-disabled") !== "true" && normalize(option.textContent || "") === expected
      );
      if (options.length === 1) {
        options[0].click();
        await sleep(250, signal);
        if (normalize(control.textContent || "") === expected || normalize(control.getAttribute("value") || "") === expected || options[0].getAttribute("aria-selected") === "true")
          return;
        break;
      }
      if (options.length > 1) break;
      await sleep(150, signal);
    }
    throw new GeneratorError(
      "GENERATION_FAILED",
      "N\xE3o foi poss\xEDvel confirmar a etiqueta cadastrada em Lojas. Nenhum link foi gerado."
    );
  }
  async function generateAffiliateLink(doc, pageUrl, productUrl, signal, onProgress = () => {
  }, timeoutMs = 45e3, campaignTag) {
    if (!isLinkBuilder(pageUrl) || !isProductLink(productUrl))
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "Abra o Gerador de links oficial com um produto v\xE1lido."
      );
    const deadline = Date.now() + timeoutMs;
    let form = null;
    onProgress("Localizando o gerador da sua conta\u2026");
    while (!form && Date.now() < deadline) {
      if (doc.querySelector(
        'input[type="password"],input[autocomplete="one-time-code"]'
      ))
        throw new GeneratorError(
          "LOGIN_REQUIRED",
          "Entre na sua conta do Mercado Livre e tente converter novamente."
        );
      form = locateGenerator(doc);
      if (!form) await sleep(250, signal);
    }
    if (!form)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "O gerador n\xE3o foi encontrado. Confirme seu login e a habilita\xE7\xE3o como afiliado."
      );
    if (signal.aborted)
      throw new GeneratorError("CANCELLED", "Convers\xE3o cancelada.");
    await applyCampaignTag(doc, campaignTag, signal);
    const { input, button, scope } = form;
    onProgress("Preenchendo o produto no gerador\u2026");
    const prototype = input instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (!setter)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "N\xE3o foi poss\xEDvel preencher o campo do gerador."
      );
    setter.call(input, productUrl);
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
    while (button.disabled && Date.now() < deadline) await sleep(250, signal);
    if (button.disabled)
      throw new GeneratorError(
        "GENERATION_FAILED",
        "O Mercado Livre n\xE3o liberou a gera\xE7\xE3o. Confira a etiqueta selecionada e o produto."
      );
    await sleep(100, signal);
    if (!input.isConnected || !button.isConnected || input.value.trim() !== productUrl)
      throw new GeneratorError(
        "FORM_NOT_FOUND",
        "O formul\xE1rio mudou durante a prepara\xE7\xE3o. Tente novamente."
      );
    const baseline = generatedOutputs(scope, input);
    const touched = /* @__PURE__ */ new Set();
    const observer = new MutationObserver((records) => {
      for (const record of records) {
        const target = record.target.nodeType === 1 ? record.target : record.target.parentElement;
        if (target) touched.add(target);
        for (const node of Array.from(record.addedNodes))
          if (node.nodeType === 1) touched.add(node);
      }
    });
    observer.observe(scope, {
      subtree: true,
      childList: true,
      attributes: true,
      characterData: true
    });
    try {
      onProgress("Gerando o link na sua conta\u2026");
      button.click();
      while (Date.now() < deadline) {
        if (signal.aborted)
          throw new GeneratorError("CANCELLED", "Convers\xE3o cancelada.");
        const outputs = generatedOutputs(scope, input).filter(
          (output) => output.link !== productUrl && (!baseline.some(
            (old) => old.element === output.element && old.link === output.link
          ) || Array.from(touched).some(
            (element) => output.element === element || output.element.contains(element)
          ))
        );
        const links = [...new Set(outputs.map((output) => output.link))];
        if (links.length === 1) return links[0];
        if (links.length > 1)
          throw new GeneratorError(
            "GENERATION_FAILED",
            "O gerador retornou mais de um link. Confira o resultado e use o retorno manual."
          );
        await sleep(250, signal);
      }
      throw new GeneratorError(
        "TIMEOUT",
        "O Mercado Livre n\xE3o confirmou um novo link. Confira login, etiqueta e elegibilidade do produto."
      );
    } finally {
      observer.disconnect();
    }
  }

  // src/affiliate/store-helper.ts
  async function start() {
    let context;
    for (let attempt = 0; attempt < 4; attempt++) {
      context = await chrome.runtime.sendMessage({ type: "AFFILIATE_CONTEXT" }).catch(() => null);
      if (isRecord(context) && context.ok === true) break;
      await new Promise((resolve) => setTimeout(resolve, 350));
    }
    if (!isRecord(context) || context.ok !== true || !validRequestId(context.requestId))
      return;
    const requestId = context.requestId;
    if (context.queued === true && (/\/(?:login|auth)(?:[/?]|$)/i.test(location.pathname) || /^auth\./i.test(location.hostname) || document.querySelector('input[type="password"]'))) {
      await chrome.runtime.sendMessage({ type: "AFFILIATE_RECONNECT", requestId }).catch(() => void 0);
      return;
    }
    const stage = context.stage;
    const productUrl = typeof context.productUrl === "string" ? context.productUrl : "";
    const abort = new AbortController();
    const host = document.createElement("div");
    host.style.cssText = "position:fixed;right:20px;bottom:20px;width:min(360px,calc(100vw - 40px));z-index:2147483647;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = ":host{font:14px system-ui;color:#f4f7ee}section{background:#15251c;border:1px solid #90b269;border-radius:18px;padding:20px;box-shadow:0 12px 40px #0005}h2{margin:0 0 10px;font-size:18px}p{line-height:1.5;font-size:13px;color:#d5e1cd}label{display:block;font-size:12px;margin:15px 0 6px}input{box-sizing:border-box;width:100%;padding:10px;border-radius:8px;border:1px solid #94a98a;background:#fff;color:#15251c}button{margin-top:12px;border:0;border-radius:9px;padding:11px 14px;background:#d7fa72;color:#15251c;font-weight:700;cursor:pointer}button:disabled{opacity:.5;cursor:wait}.close{float:right;margin:-4px -4px 0 0;padding:3px 8px;background:transparent;color:white}details{border-top:1px solid #547142;margin-top:15px;padding-top:12px}summary{cursor:pointer;font-size:12px}";
    root.append(style);
    const section = document.createElement("section");
    const title = document.createElement("h2");
    title.textContent = "Convers\xE3o do Mercado Livre";
    const description = document.createElement("p");
    description.textContent = "O PromoFlow usa o gerador oficial da conta conectada neste navegador. O link volta ao formul\xE1rio para voc\xEA revisar.";
    const status = document.createElement("p");
    status.setAttribute("role", "status");
    status.textContent = "Preparando a convers\xE3o\u2026";
    const close = document.createElement("button");
    close.className = "close";
    close.textContent = "\xD7";
    close.setAttribute("aria-label", "Cancelar convers\xE3o");
    close.onclick = () => {
      abort.abort();
      stopCopy();
      void send("AFFILIATE_CANCEL").catch(() => void 0);
      host.remove();
    };
    const details = document.createElement("details");
    const summary = document.createElement("summary");
    summary.textContent = "Usar um link gerado manualmente";
    const label = document.createElement("label");
    label.textContent = "Link gerado pela sua conta";
    label.htmlFor = "affiliate-link";
    const input = document.createElement("input");
    input.id = "affiliate-link";
    input.type = "url";
    input.maxLength = 2048;
    input.placeholder = "https://meli.la/...";
    const manual = document.createElement("button");
    manual.textContent = "Usar este link e voltar";
    const stopCopy = () => window.postMessage(
      { type: "PROMOFLOW_ML_STOP_COPY", requestId },
      location.origin
    );
    async function send(type, body = {}) {
      const result = await chrome.runtime.sendMessage({
        type,
        requestId,
        ...body
      });
      if (!isRecord(result) || result.ok !== true)
        throw new Error(
          isRecord(result) && typeof result.error === "string" ? result.error : "N\xE3o foi poss\xEDvel concluir. Volte ao formul\xE1rio e tente novamente."
        );
      return result;
    }
    async function complete(link, mode) {
      await send("AFFILIATE_COMPLETE", { affiliateUrl: link, mode });
      stopCopy();
      abort.abort();
      status.textContent = mode === "automatic" ? "Link gerado pela sua conta e enviado ao PromoFlow." : "Link manual enviado ao formul\xE1rio. Confira antes de salvar.";
      manual.disabled = true;
    }
    manual.onclick = () => {
      const link = input.value.trim();
      if (!generatedLink(link)) {
        status.textContent = "Informe um link HTTPS do Mercado Livre ou meli.la.";
        return;
      }
      manual.disabled = true;
      void complete(link, "manual").catch((error) => {
        status.textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel retornar ao formul\xE1rio.";
        manual.disabled = false;
      });
    };
    details.append(summary, label, input, manual);
    const retry = document.createElement("button");
    retry.textContent = "Retomar convers\xE3o";
    retry.hidden = stage !== "failed";
    retry.onclick = () => {
      retry.disabled = true;
      void send("AFFILIATE_RETRY").catch(() => {
        retry.disabled = false;
        status.textContent = "N\xE3o foi poss\xEDvel retomar. Tente novamente pelo PromoFlow.";
      });
    };
    section.append(close, title, description, status, retry, details);
    root.append(section);
    document.documentElement.append(host);
    window.addEventListener("message", (event) => {
      if (event.source !== window || event.origin !== location.origin || !isRecord(event.data) || event.data.type !== "PROMOFLOW_ML_LINK_COPIED" || event.data.requestId !== requestId || !mercadoLink(event.data.link))
        return;
      input.value = event.data.link;
      status.textContent = "Link copiado na loja. Confirme que pertence \xE0 sua conta antes de usar.";
      details.open = true;
    });
    const copyReady = () => {
      void send("AFFILIATE_WATCH_COPY").catch(() => void 0);
    };
    details.addEventListener("toggle", () => {
      if (details.open) copyReady();
    });
    try {
      if (stage === "resolving") {
        status.textContent = "Identificando o produto e resolvendo o link\u2026";
        let resolved = null;
        const navigationKey = `promoflow:affiliate-navigation:${requestId}`;
        let followed = false;
        try {
          followed = sessionStorage.getItem(navigationKey) === location.href;
        } catch {
        }
        for (let attempt = 0; attempt < 40 && !abort.signal.aborted; attempt++) {
          resolved = productFromPage(document, location.href);
          if (resolved) break;
          if (!followed && attempt >= 4) {
            const action = intermediateProductAction(document, location.href);
            if (action) {
              followed = true;
              try {
                sessionStorage.setItem(navigationKey, location.href);
              } catch {
              }
              status.textContent = "Abrindo o produto vinculado \xE0 promo\xE7\xE3o\u2026";
              action.click();
            }
          }
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
        if (abort.signal.aborted) return;
        if (!resolved) {
          const products = socialProducts(document, location.href);
          if (products.length > 1) {
            await send("AFFILIATE_ATTENTION");
            status.textContent = "Esta vitrine mostra v\xE1rios produtos. Escolha qual deles corresponde \xE0 oferta para continuar a convers\xE3o.";
            for (const product of products.slice(0, 8)) {
              const choose = document.createElement("button");
              choose.textContent = product.label;
              choose.style.cssText = "display:block;width:100%;text-align:left;white-space:normal;";
              choose.onclick = () => {
                choose.disabled = true;
                void send("AFFILIATE_RESOLVE", { productUrl: product.url }).catch(
                  (error) => {
                    status.textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel identificar o produto.";
                    choose.disabled = false;
                  }
                );
              };
              section.insertBefore(choose, details);
            }
            return;
          }
          throw new Error(
            "N\xE3o foi poss\xEDvel localizar o produto vinculado a esta vitrine. Abra o produto e copie o endere\xE7o direto para o formul\xE1rio do PromoFlow."
          );
        }
        await send("AFFILIATE_RESOLVE", { productUrl: resolved });
        return;
      }
      if (stage === "generating") {
        if (!isLinkBuilder(location.href))
          throw new Error(
            "Conclua o login no Mercado Livre e retorne ao Gerador de links para continuar."
          );
        const claim = await send("AFFILIATE_CLAIM");
        const resolved = typeof claim.productUrl === "string" ? claim.productUrl : productUrl;
        const link = await generateAffiliateLink(
          document,
          location.href,
          resolved,
          abort.signal,
          (text) => {
            status.textContent = text;
            void send("AFFILIATE_PROGRESS", {
              step: text.startsWith("Preenchendo") ? "filling" : "generating"
            }).catch(() => void 0);
          },
          45e3,
          typeof claim.campaignTag === "string" ? claim.campaignTag : void 0
        );
        if (!abort.signal.aborted) await complete(link, "automatic");
        return;
      }
      status.textContent = "Esta solicita\xE7\xE3o n\xE3o est\xE1 em convers\xE3o autom\xE1tica. Gere seu link na loja e use o retorno manual ou inicie novamente pelo PromoFlow.";
      details.open = true;
    } catch (error) {
      if (abort.signal.aborted) return;
      status.textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel converter automaticamente. Confira a conta conectada e tente novamente.";
      details.open = true;
      copyReady();
      void send("AFFILIATE_FAILED").then(() => {
        retry.hidden = false;
      }).catch(() => void 0);
    }
  }
  void start();
})();
