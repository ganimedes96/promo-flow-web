"use strict";
var PromoFlowCapture = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/collector/index.ts
  var index_exports = {};
  __export(index_exports, {
    result: () => result
  });

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };

  // src/shared/urls.ts
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function largerImage(url) {
    if (url.hostname !== "http2.mlstatic.com") return url.href;
    const match = url.pathname.match(
      /^\/D_([A-Z0-9_]+)_(\d+-ML[A-Z]\d+_\d+)-([A-Z])(?:-[^/]*)?\.(?:webp|jpe?g|png)$/i
    );
    if (!match || match[1].startsWith("NQ_NP") && ["O", "F"].includes(match[3]))
      return url.href;
    return "https://http2.mlstatic.com/D_NQ_NP_" + match[2] + "-O.webp";
  }

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function cleanText(value, max) {
    return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
  }

  // src/collector/shared/dom.ts
  function visible(selector) {
    return [...document.querySelectorAll(selector)].find(
      (node) => node.getClientRects().length > 0 && getComputedStyle(node).visibility !== "hidden"
    );
  }
  function meta(key) {
    return [...document.querySelectorAll("meta")].find(
      (node) => (node.getAttribute("property") || node.getAttribute("name") || "").toLowerCase() === key
    )?.content;
  }

  // src/collector/shared/metadata.ts
  function structuredProduct() {
    const queue = [];
    for (const script of [
      ...document.querySelectorAll('script[type="application/ld+json"]')
    ].slice(0, LIMITS.jsonScripts)) {
      const raw = script.textContent || "";
      if (raw.length > LIMITS.jsonScript) continue;
      try {
        const value = JSON.parse(raw);
        queue.push(value);
      } catch {
      }
    }
    let count = 0;
    while (queue.length && count++ < LIMITS.metadataNodes) {
      const node = queue.shift();
      if (Array.isArray(node)) {
        queue.push(...node.slice(0, 100));
        continue;
      }
      if (!isRecord(node)) continue;
      const types = Array.isArray(node["@type"]) ? node["@type"] : [node["@type"]];
      if (types.some(
        (type) => typeof type === "string" && /(?:^|[/#])Product$/.test(type)
      ))
        return node;
      for (const key of ["@graph", "mainEntity", "itemListElement", "item"])
        if (node[key]) queue.push(node[key]);
    }
    return void 0;
  }

  // src/shared/money.ts
  function parseMoney(value) {
    if (typeof value !== "number" && typeof value !== "string") return null;
    let raw = String(value).trim();
    if (raw.includes(",")) raw = raw.replace(/\./g, "").replace(",", ".");
    if (!/^\d+(?:\.\d{1,2})?$/.test(raw)) return null;
    const result2 = Number(raw);
    return Number.isFinite(result2) && result2 > 0 && result2 <= LIMITS.price ? result2 : null;
  }

  // src/collector/mercado-livre/prices.ts
  function readPrices(product) {
    const first = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
    const offer = isRecord(first) ? first : {};
    const currency = cleanText(
      offer.priceCurrency || meta("product:price:currency"),
      10
    ).toUpperCase();
    const amount = (selector) => {
      const node = visible(selector);
      if (!node) return null;
      const symbol = cleanText(
        node.querySelector(".andes-money-amount__currency-symbol")?.textContent,
        10
      );
      if (symbol !== "R$" && node.getAttribute("data-currency-id") !== "BRL" && currency !== "BRL" && !node.closest(".ui-pdp-price")?.textContent?.includes("R$"))
        return null;
      const fraction = cleanText(
        node.querySelector(".andes-money-amount__fraction")?.textContent,
        30
      ).replace(/\./g, "");
      const cents = cleanText(
        node.querySelector(".andes-money-amount__cents")?.textContent,
        3
      );
      if (!fraction || cents && !/^\d{1,2}$/.test(cents)) return null;
      return parseMoney(fraction + (cents ? "," + cents.padStart(2, "0") : ""));
    };
    const currentPrice = amount(".ui-pdp-price__second-line .andes-money-amount:not(s)") ?? (currency === "BRL" ? parseMoney(offer.price ?? meta("product:price:amount")) : null);
    const specs = Array.isArray(offer.priceSpecification) ? offer.priceSpecification : [offer.priceSpecification];
    const old = specs.find(
      (spec) => isRecord(spec) && typeof spec.priceType === "string" && /(?:^|[/#])StrikethroughPrice$/.test(spec.priceType) && spec.priceCurrency === "BRL"
    );
    const oldPrice = amount(".ui-pdp-price__original-value") ?? amount(
      ".ui-pdp-price s.andes-money-amount, .ui-pdp-price s .andes-money-amount, .ui-pdp-price .andes-money-amount--previous"
    ) ?? parseMoney(old?.price);
    return {
      currentPrice,
      originalPrice: oldPrice !== null && currentPrice !== null && oldPrice > currentPrice ? oldPrice : null
    };
  }

  // src/collector/mercado-livre/images.ts
  function readImages(product) {
    const images = /* @__PURE__ */ new Set();
    const add = (value) => {
      if (images.size >= LIMITS.images || typeof value !== "string") return;
      try {
        const url = new URL(value, location.href);
        if (url.protocol === "https:" && (url.hostname === "mlstatic.com" || url.hostname.endsWith(".mlstatic.com")) && !url.username && !url.password && url.href.length <= LIMITS.url)
          images.add(largerImage(url));
      } catch {
      }
    };
    for (const image of document.querySelectorAll(
      ".ui-pdp-gallery__figure img, img.ui-pdp-image"
    ))
      add(
        image.getAttribute("data-zoom") || image.getAttribute("data-src") || image.currentSrc || image.src
      );
    const values = Array.isArray(product?.image) ? product.image : [product?.image];
    for (const value of values)
      add(isRecord(value) ? value.contentUrl || value.url : value);
    add(meta("og:image"));
    return [...images];
  }

  // src/collector/mercado-livre/index.ts
  function captureProduct() {
    if (!isMercadoLivreHost(location.hostname))
      throw new Error(
        "Abra o an\xFAncio direto do produto no Mercado Livre antes de capturar."
      );
    const product = structuredProduct();
    const heading = visible('h1.ui-pdp-title, h1[itemprop="name"]');
    const productPath = /(?:^\/MLB-?\d+(?:-|_|\/|$)|\/p\/MLB\d+(?:\/|$))/i.test(
      location.pathname
    );
    if (!heading && !(productPath && product))
      throw new Error(
        "Esta p\xE1gina n\xE3o parece ser um an\xFAncio. Abra o produto, aguarde carregar e tente novamente."
      );
    const prices = readPrices(product);
    const imageUrls = readImages(product);
    const attributes = [...document.querySelectorAll(".ui-pdp-specs__table tr")].slice(0, 12).flatMap((row) => {
      const label = cleanText(row.querySelector("th")?.textContent, 100), value = cleanText(row.querySelector("td")?.textContent, 200);
      return label && value ? [label + ": " + value] : [];
    });
    const title = cleanText(
      heading?.textContent || product?.name || meta("og:title"),
      LIMITS.title
    ).replace(/\s*\|\s*Mercado\s*Livre.*$/i, "");
    const description = cleanText(
      document.querySelector(".ui-pdp-description__content")?.textContent || product?.description,
      LIMITS.description
    ) || attributes.join("\n").slice(0, LIMITS.description) || cleanText(meta("og:description"), LIMITS.description);
    const sourceUrl = new URL(location.href);
    sourceUrl.hash = "";
    if (sourceUrl.href.length > LIMITS.url)
      throw new Error(
        "O link do an\xFAncio \xE9 muito longo. Abra o link direto do produto."
      );
    const warnings = [];
    if (!title) warnings.push("T\xEDtulo n\xE3o encontrado.");
    if (!description)
      warnings.push(
        "Descri\xE7\xE3o n\xE3o encontrada. Abra a descri\xE7\xE3o do an\xFAncio e capture novamente, ou complete no PromoFlow."
      );
    if (!imageUrls.length) warnings.push("Imagem n\xE3o encontrada.");
    if (prices.originalPrice === null)
      warnings.push(
        "Pre\xE7o antigo n\xE3o encontrado ou sem desconto confirmado. A oferta ficar\xE1 somente com o pre\xE7o atual."
      );
    if (prices.currentPrice === null)
      warnings.push("Pre\xE7o n\xE3o encontrado. Informe o valor final manualmente.");
    warnings.push(
      "Confira a varia\xE7\xE3o, pre\xE7o \xE0 vista, frete e condi\xE7\xF5es de cupom antes de salvar."
    );
    return {
      version: 1,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      draft: {
        sourceUrl: sourceUrl.href,
        title,
        description,
        imageUrls,
        ...prices
      },
      warnings
    };
  }

  // src/collector/amazon/prices.ts
  function readAmazonPrices(product) {
    const read = (selectors) => {
      for (const selector of selectors) {
        const node = visible(selector);
        if (!node) continue;
        const whole = node.querySelector(".a-price-whole");
        const cents = node.querySelector(".a-price-fraction");
        const offscreen = node.querySelector(".a-offscreen");
        if (!offscreen && whole && cents && node.textContent?.includes("R$")) {
          const fraction = cleanText(whole.textContent, 30).replace(
            /[^0-9]/g,
            ""
          );
          const decimal = cleanText(cents.textContent, 3);
          if (/^\d{1,2}$/.test(decimal)) {
            const amount = parseMoney(fraction + "," + decimal.padStart(2, "0"));
            if (amount !== null) return amount;
          }
        }
        const raw = cleanText(
          offscreen?.textContent || (!whole ? node.textContent : ""),
          100
        );
        const match = raw.match(/R\$\s*([\d.]+(?:,\d{1,2})?)/);
        if (match) {
          const amount = parseMoney(match[1]);
          if (amount !== null) return amount;
        }
      }
      return null;
    };
    const first = Array.isArray(product?.offers) ? product.offers[0] : product?.offers;
    const offer = isRecord(first) ? first : {};
    const currentPrice = read([
      "#corePriceDisplay_desktop_feature_div .priceToPay",
      "#corePrice_feature_div .priceToPay",
      "#apex_desktop .apexPriceToPay",
      "#corePriceDisplay_desktop_feature_div .a-price:not(.a-text-price)",
      "#corePrice_feature_div .a-price:not(.a-text-price)",
      "#priceblock_dealprice",
      "#priceblock_ourprice",
      "#priceblock_saleprice",
      "#price_inside_buybox",
      "#newBuyBoxPrice"
    ]) ?? (offer.priceCurrency === "BRL" ? parseMoney(offer.price) : null);
    const original = read([
      "#corePriceDisplay_desktop_feature_div .basisPrice .a-text-price",
      '#corePriceDisplay_desktop_feature_div .a-text-price[data-a-strike="true"]',
      "#corePriceDisplay_desktop_feature_div .basisPrice",
      "#corePrice_feature_div .basisPrice .a-text-price",
      '#corePrice_feature_div .a-text-price[data-a-strike="true"]',
      "#price .a-text-price"
    ]);
    return {
      currentPrice,
      originalPrice: original !== null && currentPrice !== null && original > currentPrice ? original : null
    };
  }

  // src/collector/amazon/images.ts
  function readAmazonImages(product) {
    const images = /* @__PURE__ */ new Set();
    const identities = /* @__PURE__ */ new Set();
    const add = (value, thumbnail = false) => {
      if (typeof value !== "string" || images.size >= LIMITS.images) return;
      try {
        const url = new URL(value, location.href);
        if (url.protocol !== "https:" || !isProductImageHost(url.hostname) || url.username || url.password || url.href.length > LIMITS.url)
          return;
        if (thumbnail)
          url.pathname = url.pathname.replace(
            /\._[^/]+_\.(jpe?g|png|webp)$/i,
            ".$1"
          );
        const identity = url.hostname + url.pathname.replace(/\._[^/]+_\.(jpe?g|png|webp)$/i, ".$1");
        if (identities.has(identity)) return;
        identities.add(identity);
        images.add(url.href);
      } catch {
      }
    };
    for (const image of document.querySelectorAll(
      "#landingImage, #imgBlkFront, #ebooksImgBlkFront, #imageBlock img.a-dynamic-image"
    )) {
      add(image.getAttribute("data-old-hires"));
      const raw = image.getAttribute("data-a-dynamic-image");
      if (raw && raw.length <= 5e4) {
        try {
          const dynamic = JSON.parse(raw);
          if (isRecord(dynamic)) {
            const entries = Object.entries(dynamic).map(([url, dimensions]) => {
              const size = Array.isArray(dimensions) && typeof dimensions[0] === "number" && typeof dimensions[1] === "number" ? dimensions[0] * dimensions[1] : 0;
              return { url, size };
            }).sort((a, b) => b.size - a.size);
            if (entries[0]) add(entries[0].url);
          }
        } catch {
        }
      }
      if (!images.size) add(image.currentSrc || image.src, true);
    }
    const values = Array.isArray(product?.image) ? product.image : [product?.image];
    for (const image of values)
      add(isRecord(image) ? image.contentUrl || image.url : image);
    for (const image of document.querySelectorAll(
      "#altImages li.imageThumbnail img"
    ))
      add(image.getAttribute("data-src") || image.currentSrc || image.src, true);
    add(meta("og:image"));
    return [...images];
  }

  // src/collector/amazon/index.ts
  function captureAmazonProduct() {
    if (!isAmazonHost(location.hostname))
      throw new Error("Abra o produto na Amazon Brasil.");
    const heading = visible("#productTitle, #title #title");
    const input = document.querySelector(
      '#ASIN, input[name="ASIN"]'
    );
    const pathAsin = location.pathname.match(
      /\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})(?:\/|$)/i
    )?.[1];
    const asin = /^[A-Z0-9]{10}$/i.test(input?.value || "") ? input?.value : pathAsin;
    if (!heading || !asin)
      throw new Error(
        "Esta p\xE1gina n\xE3o parece ser um produto da Amazon. Abra o an\xFAncio, escolha a varia\xE7\xE3o e aguarde carregar."
      );
    const product = structuredProduct();
    const title = cleanText(heading.textContent || product?.name, LIMITS.title);
    const bullets = [
      ...document.querySelectorAll("#feature-bullets li .a-list-item")
    ].map((node) => cleanText(node.textContent, 600)).filter((value) => value && !/^ver mais|^veja mais/i.test(value));
    const description = (bullets.length ? bullets.join("\n") : cleanText(
      document.querySelector("#productDescription")?.textContent || product?.description,
      LIMITS.description
    )).slice(0, LIMITS.description);
    const prices = readAmazonPrices(product), imageUrls = readAmazonImages(product);
    const originalUrl = new URL(location.href);
    originalUrl.hash = "";
    let sourceUrl = originalUrl;
    if (asin !== pathAsin || originalUrl.href.length > LIMITS.url) {
      sourceUrl = new URL("/dp/" + asin, location.origin);
      for (const key of ["smid", "tag", "linkCode", "th", "psc"]) {
        const value = originalUrl.searchParams.get(key);
        if (value && value.length < 200) sourceUrl.searchParams.set(key, value);
      }
    }
    const warnings = [];
    if (!description)
      warnings.push("Descri\xE7\xE3o n\xE3o encontrada. Complete no PromoFlow.");
    if (!imageUrls.length) warnings.push("Imagem n\xE3o encontrada.");
    if (prices.currentPrice === null)
      warnings.push("Pre\xE7o em reais n\xE3o encontrado. Informe manualmente.");
    if (prices.originalPrice === null)
      warnings.push("Pre\xE7o antigo n\xE3o encontrado ou sem desconto confirmado.");
    warnings.push(
      "Confira varia\xE7\xE3o, vendedor, CEP, Prime, Pix e cupom na Amazon. O pre\xE7o capturado n\xE3o inclui descontos condicionais n\xE3o aplicados."
    );
    return {
      version: 1,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      draft: {
        sourceUrl: sourceUrl.href,
        title,
        description,
        imageUrls,
        ...prices
      },
      warnings
    };
  }

  // src/collector/index.ts
  function capture() {
    if (isAmazonHost(location.hostname)) return captureAmazonProduct();
    if (isMercadoLivreHost(location.hostname)) return captureProduct();
    throw new Error("Abra um produto no Mercado Livre ou na Amazon Brasil.");
  }
  var result = capture();
  return __toCommonJS(index_exports);
})();
PromoFlowCapture.result;
