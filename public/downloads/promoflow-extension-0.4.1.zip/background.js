"use strict";
(() => {
  // src/shared/urls.ts
  function isAmazonHost(host) {
    return host === "amazon.com.br" || host.endsWith(".amazon.com.br");
  }
  function isProductHost(host) {
    return isMercadoLivreHost(host) || isAmazonHost(host);
  }
  function isProductImageHost(host) {
    return [
      "mlstatic.com",
      "media-amazon.com",
      "ssl-images-amazon.com",
      "images-amazon.com"
    ].some((domain) => host === domain || host.endsWith("." + domain));
  }
  function isMercadoLivreHost(host) {
    return host === "mercadolivre.com.br" || host.endsWith(".mercadolivre.com.br");
  }
  function isAffiliateUrl(value) {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && !url.username && !url.password && (isProductHost(url.hostname) || ["meli.la", "www.meli.la", "amzn.to", "a.co"].includes(url.hostname));
    } catch {
      return false;
    }
  }

  // src/shared/config.ts
  var LIMITS = {
    title: 200,
    description: 2e3,
    url: 2048,
    images: 8,
    jsonScript: 2e5,
    jsonScripts: 20,
    metadataNodes: 500,
    fragment: 6e4,
    price: 999999999999e-2
  };
  var DESTINATIONS = [
    "https://promo-flow-web-zeta.vercel.app",
    "http://localhost:3000"
  ];

  // src/shared/value.ts
  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }
  function errorMessage(error, fallback) {
    return error instanceof Error ? error.message : fallback;
  }

  // src/shared/validation.ts
  function validPrice(value) {
    return value === null || typeof value === "number" && Number.isFinite(value) && value > 0 && value <= LIMITS.price;
  }
  function isCapturedProduct(value) {
    if (!isRecord(value) || value.version !== 1 || typeof value.capturedAt !== "string" || !Number.isFinite(Date.parse(value.capturedAt)) || !isRecord(value.draft))
      return false;
    const draft = value.draft;
    if (typeof draft.sourceUrl !== "string" || draft.sourceUrl.length > LIMITS.url)
      return false;
    try {
      const url = new URL(draft.sourceUrl);
      if (url.protocol !== "https:" || url.username || url.password || !isProductHost(url.hostname))
        return false;
    } catch {
      return false;
    }
    return typeof draft.title === "string" && draft.title.length <= LIMITS.title && typeof draft.description === "string" && draft.description.length <= LIMITS.description && validPrice(draft.currentPrice) && validPrice(draft.originalPrice) && Array.isArray(draft.imageUrls) && draft.imageUrls.length <= LIMITS.images && draft.imageUrls.every((image) => {
      if (typeof image !== "string" || image.length > LIMITS.url) return false;
      try {
        const url = new URL(image);
        return url.protocol === "https:" && !url.username && !url.password && isProductImageHost(url.hostname);
      } catch {
        return false;
      }
    }) && Array.isArray(value.warnings) && value.warnings.length <= 10 && value.warnings.every(
      (warning) => typeof warning === "string" && warning.length <= 300
    );
  }

  // src/services/chrome-capture.ts
  async function captureActiveProduct(commandTab) {
    const tab = commandTab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
    if (!tab?.id || !tab.url)
      throw new Error(
        "N\xE3o foi poss\xEDvel identificar a aba. Abra o an\xFAncio no Mercado Livre ou na Amazon Brasil."
      );
    if (!isProductHost(new URL(tab.url).hostname))
      throw new Error(
        "Abra um produto no Mercado Livre ou na Amazon Brasil. Se estiver usando link curto, aguarde o redirecionamento."
      );
    const [injection] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["collector.js"]
    });
    const data = injection?.result;
    if (!isCapturedProduct(data))
      throw new Error(
        "N\xE3o foi poss\xEDvel ler o an\xFAncio. Aguarde a p\xE1gina carregar e tente novamente."
      );
    return data;
  }

  // src/services/promoflow.ts
  async function openDraft(captured, options) {
    if (!DESTINATIONS.includes(options.destination))
      throw new Error("Destino do PromoFlow inv\xE1lido.");
    const affiliateUrl = options.affiliateUrl.trim(), couponCode = options.couponCode.trim();
    if (affiliateUrl && (affiliateUrl.length > LIMITS.url || !isAffiliateUrl(affiliateUrl)))
      throw new Error(
        "Informe um link de afiliado HTTPS do Mercado Livre, Amazon Brasil ou seus links curtos."
      );
    if (couponCode.length > 100)
      throw new Error("O cupom deve ter at\xE9 100 caracteres.");
    const payload = {
      ...captured,
      draft: { ...captured.draft, affiliateUrl, couponCode }
    };
    const fragment = encodeURIComponent(JSON.stringify(payload));
    if (fragment.length > LIMITS.fragment)
      throw new Error(
        "Os dados ficaram muito grandes. Tente capturar novamente."
      );
    await chrome.tabs.create({
      url: options.destination + "/import-product#promoflow=" + fragment
    });
  }

  // src/background/index.ts
  var capturing = false;
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "capture-product" || capturing) return;
    capturing = true;
    void (async () => {
      try {
        await chrome.action.setBadgeText({ text: "..." });
        const product = await captureActiveProduct(tab);
        await openDraft(product, {
          destination: DESTINATIONS[0],
          affiliateUrl: "",
          couponCode: ""
        });
        await chrome.action.setBadgeText({ text: "" });
        await chrome.action.setTitle({
          title: "Importar produto para o PromoFlow"
        });
      } catch (error) {
        await chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
        await chrome.action.setBadgeText({ text: "!" });
        await chrome.action.setTitle({
          title: "Falha ao importar: " + errorMessage(error, "Abra um produto e tente novamente.").slice(
            0,
            220
          )
        });
      } finally {
        capturing = false;
      }
    })().catch((error) => {
      capturing = false;
      console.error(errorMessage(error, "Falha ao importar produto."));
    });
  });
})();
